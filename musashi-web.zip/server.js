import fs from "node:fs";
import { loadConfig } from "./server/config.js";
import { createStore } from "./server/store.js";
import { createApp } from "./server/app.js";
import { createMockAdapter } from "./server/adapters/mock.js";

// قراءة .env اختيارياً (Node >= 20.12) دون مكتبات.
if (fs.existsSync(".env")) process.loadEnvFile?.(".env");

/**
 * يشغّل الموقع. عند التضمين داخل البوت مرّر adapter حقيقياً:
 *   startWeb({ adapter: createRealAdapter({ SubBots, mainSock }) })
 */
export function startWeb({ adapter, env = process.env } = {}) {
  const cfg = loadConfig(env);
  if (!adapter) {
    if (cfg.adapter !== "mock") throw new Error("BOT_ADAPTER=real يتطلب تمرير adapter من ملف تشغيل البوت (startWeb({ adapter })).");
    adapter = createMockAdapter();
  }
  const store = createStore(cfg.dataFile || null);
  const { app } = createApp({ cfg, store, adapter });
  const server = app.listen(cfg.port, cfg.host, () => {
    console.log(`MUSASHI site على http://${cfg.host}:${cfg.port}  (adapter: ${cfg.adapter})`);
    if (cfg.ephemeralSecret) console.warn("⚠️ SESSION_SECRET غير مضبوط: سيُولَّد عشوائياً وتنتهي الجلسات عند كل إعادة تشغيل.");
    if (!cfg.devPasswordHash) console.warn("⚠️ DEV_PASSWORD_HASH غير مضبوط: لوحة المطور معطّلة. ولّده بـ: npm run hash-password");
  });
  const stop = () => { store.flush(); server.close(() => process.exit(0)); };
  process.on("SIGINT", stop); process.on("SIGTERM", stop);
  return { server, app };
}

if (import.meta.url === `file://${process.argv[1]}`) startWeb();
