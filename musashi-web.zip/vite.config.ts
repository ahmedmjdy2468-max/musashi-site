import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" => يعمل على أي مسار (GitHub Pages، مجلد فرعي، استضافة ثابتة).
export default defineConfig({ base: "./", plugins: [react()] });
