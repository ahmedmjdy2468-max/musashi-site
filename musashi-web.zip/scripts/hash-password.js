import readline from "node:readline";
import { hashPassword } from "../server/security.js";

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.question("كلمة سر المطور (12 حرفاً على الأقل): ", (pw) => {
  rl.close();
  if (pw.length < 12) { console.error("قصيرة جداً."); process.exit(1); }
  console.log("\nضع هذا في .env:\nDEV_PASSWORD_HASH=" + hashPassword(pw));
});
