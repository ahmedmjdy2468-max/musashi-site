import express from "express";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {
  sha256, hmac, randomToken, safeEqual, signValue, unsignValue, parseCookies, setCookie, clearCookie,
  createLimiter, createLockout, verifyPassword,
} from "./security.js";
import { createHub } from "./hub.js";
import { normPhone, maskPhone, cleanText, hasLink, hasBadWord, normalizeArabic, validAvatar } from "./util.js";
import { BAD_WORDS } from "./badwords.js";

const DAY = 86_400_000;
const OWNER_TTL = 30 * DAY;
const DEV_TTL = 12 * 3_600_000;
const CODE_TTL = 5 * 60_000;
const COMPLAINT_TYPES = { bug: "مشكلة تقنية", suggestion: "اقتراح", account: "حساب / تنصيب", other: "أخرى" };
const COMPLAINT_STATUS = ["new", "review", "resolved"];
const ACTIVE_STATES = new Set(["connected", "stopped"]);

export function createApp({ cfg, store, adapter }) {
  const db = store.data;
  const hub = createHub();
  const limiter = createLimiter();
  const loginLock = createLockout(5, 15 * 60_000);
  const devLock = createLockout(5, 15 * 60_000);
  const codes = new Map();       // phone -> { hash, exp }
  const watches = new Map();     // token -> { phone, exp, last: [event, data] | null }
  const chatLast = new Map();    // uid -> ts آخر رسالة

  const extraBad = cfg.extraBadWordsFile && fs.existsSync(cfg.extraBadWordsFile)
    ? fs.readFileSync(cfg.extraBadWordsFile, "utf8").split(/\r?\n/).map((s) => s.trim()).filter(Boolean) : [];
  const badWords = [...BAD_WORDS, ...extraBad].map((w) => normalizeArabic(w).trim());

  // ───────── أدوات مساعدة ─────────
  const now = () => Date.now();
  const botId = (phone) => sha256("bot:" + phone + cfg.sessionSecret).slice(0, 12);
  const botByPhone = (phone) => db.bots[phone];
  const botById = (id) => Object.values(db.bots).find((b) => b.id === id);
  const stateOf = (phone) => adapter.state(phone);
  const isActive = (phone) => ACTIVE_STATES.has(stateOf(phone));

  function logEvent(type, phone, detail = "") {
    db.events.push({ id: store.nextId(), ts: now(), type, phone: phone ? maskPhone(phone) : "", detail });
    if (db.events.length > 1000) db.events.splice(0, db.events.length - 1000);
    store.save();
    hub.publish("dev", "event", db.events[db.events.length - 1]);
  }

  const sessionKey = (sid) => sha256(sid);
  function createSession(req, res, role, phone) {
    const sid = randomToken(32);
    const ttl = role === "dev" ? DEV_TTL : OWNER_TTL;
    db.sessions[sessionKey(sid)] = { role, phone: phone || null, exp: now() + ttl, createdAt: now() };
    store.save();
    setCookie(req, res, cfg, role === "dev" ? "md" : "ms", signValue(cfg.sessionSecret, sid), Math.floor(ttl / 1000));
  }
  function readSession(req, role) {
    const raw = parseCookies(req.headers.cookie)[role === "dev" ? "md" : "ms"];
    const sid = unsignValue(cfg.sessionSecret, raw);
    if (!sid) return null;
    const s = db.sessions[sessionKey(sid)];
    if (!s || s.role !== role || s.exp < now()) return null;
    // تمديد منزلق
    const ttl = role === "dev" ? DEV_TTL : OWNER_TTL;
    if (s.exp - now() < ttl / 2) { s.exp = now() + ttl; store.save(); }
    return { sid, ...s };
  }
  const destroySession = (sid) => { delete db.sessions[sessionKey(sid)]; store.save(); };
  function revokeOwnerSessions(phone) {
    let n = 0;
    for (const [k, s] of Object.entries(db.sessions)) if (s.role === "owner" && s.phone === phone) { delete db.sessions[k]; n++; }
    store.save();
    return n;
  }
  function forceLogout(phone, reason) {
    const n = revokeOwnerSessions(phone);
    hub.publish(`owner:${phone}`, "forced-logout", { reason });
    hub.close(`owner:${phone}`);
    logEvent("forced_logout", phone, `${reason} (جلسات ملغاة: ${n})`);
  }

  // ───────── أحداث البوت (pair / ready / close / badSession) ─────────
  const watchersOf = (phone) => [...watches.entries()].filter(([, w]) => w.phone === phone);
  function toWatchers(phone, event, data) {
    for (const [t, w] of watchersOf(phone)) { w.last = [event, data]; hub.publish(`watch:${t}`, event, data); }
  }
  adapter.on("pair", ({ phone, code }) => {
    if (!botByPhone(phone)) return;
    logEvent("pair_code_shown", phone);
    toWatchers(phone, "pair", { code: code || cfg.pairCode });
  });
  adapter.on("ready", ({ phone }) => {
    const b = botByPhone(phone);
    if (!b) return;
    b.status = "connected"; b.connectedAt = now(); b.updatedAt = now();
    store.save();
    logEvent("bot_ready", phone);
    toWatchers(phone, "ready", { message: "✅ تم ربط بوتك بنجاح" });
    hub.publish(`owner:${phone}`, "status", { status: "connected" });
  });
  async function onDisconnect(phone, kind) {
    const b = botByPhone(phone);
    if (!b) return;
    b.status = "disconnected"; b.updatedAt = now();
    store.save();
    if (kind === "badSession") {
      try { await adapter.cleanSession(phone); } catch (e) { logEvent("clean_session_failed", phone, e.message); }
    }
    forceLogout(phone, kind);
    toWatchers(phone, "close", { kind });
  }
  adapter.on("close", ({ phone }) => onDisconnect(phone, "close"));
  adapter.on("badSession", ({ phone }) => onDisconnect(phone, "badSession"));

  // ───────── التطبيق ─────────
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", cfg.trustProxy);

  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    res.setHeader("Content-Security-Policy",
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
      "font-src https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self'; connect-src 'self'; " +
      "frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    if (req.secure) res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    next();
  });

  app.use("/api", express.json({ limit: "20kb" }));
  app.use("/api/chat/join", express.json({ limit: "160kb" }));

  // حماية CSRF: طلبات التعديل يجب أن تأتي من نفس الأصل.
  app.use("/api", (req, res, next) => {
    if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
    const origin = req.headers.origin;
    if (origin) {
      let ok = false;
      try { ok = new URL(origin).host === req.headers.host || cfg.allowedOrigins.includes(origin); } catch { /* مرفوض */ }
      if (!ok) return res.status(403).json({ error: "ORIGIN", message: "طلب مرفوض (أصل غير مسموح)." });
    } else if (req.headers["sec-fetch-site"] === "cross-site") {
      return res.status(403).json({ error: "ORIGIN", message: "طلب مرفوض." });
    }
    next();
  });

  const limit = (name, n, windowMs, keyFn = (req) => req.ip) => (req, res, next) => {
    const r = limiter.hit(`${name}:${keyFn(req)}`, n, windowMs);
    if (r.ok) return next();
    res.setHeader("Retry-After", r.retryAfter);
    res.status(429).json({ error: "RATE_LIMIT", message: "طلبات كثيرة، حاول لاحقاً.", retryAfter: r.retryAfter });
  };
  const bad = (res, status, error, message, extra = {}) => res.status(status).json({ error, message, ...extra });

  const requireOwner = (req, res, next) => {
    const s = readSession(req, "owner");
    if (!s) return bad(res, 401, "UNAUTH", "سجّل الدخول أولاً.");
    const st = stateOf(s.phone);
    if (!botByPhone(s.phone) || !ACTIVE_STATES.has(st)) {
      destroySession(s.sid);
      clearCookie(req, res, cfg, "ms");
      return bad(res, 401, "DISCONNECTED", "البوت منفصل ⚠️ — أعد التنصيب", { disconnected: true });
    }
    req.owner = { phone: s.phone, sid: s.sid };
    next();
  };
  const requireDev = (req, res, next) => {
    const s = readSession(req, "dev");
    if (!s) return bad(res, 401, "UNAUTH", "دخول المطور مطلوب.");
    req.dev = { sid: s.sid };
    next();
  };

  // ───────── عام ─────────
  app.get("/api/health", (req, res) => res.json({ ok: true }));

  app.get("/api/stats", (req, res) => {
    const bots = Object.values(db.bots);
    const active = bots.filter((b) => ACTIVE_STATES.has(stateOf(b.phone))).length;
    const registered = bots.length;
    res.json({
      total: cfg.maxBots,
      available: Math.max(0, cfg.maxBots - registered),
      active,
      disconnected: bots.filter((b) => ["disconnected", "none"].includes(stateOf(b.phone)) && b.status !== "pairing").length,
    });
  });

  app.get("/api/announcements", (req, res) =>
    res.json({ items: db.announcements.slice(-20).reverse() }));
  app.get("/api/channel", (req, res) =>
    res.json({ url: cfg.channelUrl || null, announcements: db.announcements.slice(-10).reverse() }));

  app.get("/api/commands", (req, res) => {
    const cats = adapter.commands() || [];
    res.json({ total: cats.reduce((n, c) => n + c.commands.length, 0),
      categories: cats.map((c) => ({ id: c.id, icon: c.icon, title: c.title, count: c.commands.length })) });
  });
  app.get("/api/commands/:id", (req, res) => {
    const c = (adapter.commands() || []).find((x) => x.id === req.params.id);
    if (!c) return bad(res, 404, "NOT_FOUND", "التصنيف غير موجود.");
    res.json({ id: c.id, icon: c.icon, title: c.title, count: c.commands.length, commands: c.commands });
  });

  // ───────── التنصيب ─────────
  app.post("/api/install", limit("install", 5, 3_600_000), async (req, res) => {
    const phone = normPhone(req.body?.phone);
    if (!phone) return bad(res, 400, "PHONE", "أدخل رقماً صحيحاً بصيغة دولية (مثل 9689xxxxxxx).");
    const existing = botByPhone(phone);
    if (existing && isActive(phone)) {
      return bad(res, 409, "ACTIVE", "البوت مفعّل ✅", { active: true });
    }
    if (!existing && Object.keys(db.bots).length >= cfg.maxBots) {
      return bad(res, 409, "FULL", "لا توجد أماكن متاحة حالياً.");
    }
    try {
      if (existing) await adapter.cleanSession(phone); // الجلسة التالفة فقط، بيانات UltraDB تبقى
      const rec = existing || (db.bots[phone] = { id: botId(phone), phone, createdAt: now() });
      rec.status = "pairing"; rec.updatedAt = now();
      store.save();
      const token = randomToken(16);
      watches.set(token, { phone, exp: now() + 15 * 60_000, last: null });
      logEvent(existing ? "reinstall_requested" : "install_requested", phone);
      await adapter.requestPair(phone, cfg.pairCode);
      res.json({ ok: true, watch: token, reinstall: Boolean(existing) });
    } catch (e) {
      logEvent("install_failed", phone, e.message);
      bad(res, 502, "ADAPTER", "تعذّر بدء الإقران حالياً، حاول بعد قليل.");
    }
  });

  app.get("/api/install/events", (req, res) => {
    const t = String(req.query.t || "");
    const w = watches.get(t);
    if (!w || w.exp < now()) return bad(res, 404, "WATCH", "انتهت صلاحية المتابعة. ابدأ التنصيب من جديد.");
    hub.subscribe(req, res, `watch:${t}`, w.last ? [w.last] : []);
  });

  // ───────── دخول المالك ─────────
  app.post("/api/auth/request", limit("auth-ip", 10, 10 * 60_000), async (req, res) => {
    const phone = normPhone(req.body?.phone);
    if (!phone) return bad(res, 400, "PHONE", "أدخل رقماً صحيحاً.");
    const r = limiter.hit(`auth-phone:${phone}`, 3, 10 * 60_000);
    if (!r.ok) return bad(res, 429, "RATE_LIMIT", "طلبت أكواداً كثيرة، انتظر قليلاً.", { retryAfter: r.retryAfter });
    const lock = loginLock.check(phone);
    if (lock.locked) return bad(res, 423, "LOCKED", "الحساب مقفل مؤقتاً بسبب محاولات خاطئة.", { retryAfter: lock.retryAfter });
    // رد موحّد سواء كان الرقم مسجلاً أم لا (منع تعداد الأرقام)
    const generic = { ok: true, message: "إن كان الرقم مسجلاً فقد أُرسل إليه رمز تحقق على واتساب." };
    if (!botByPhone(phone)) return res.json(generic);
    const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, "0");
    codes.set(phone, { hash: hmac(cfg.sessionSecret, `${phone}:${code}`), exp: now() + CODE_TTL });
    try {
      await adapter.sendMain(phone, `🔐 رمز دخول MUSASHI: ${code}\nصالح 5 دقائق ويُستخدم مرة واحدة.\nإن لم تطلبه فتجاهل الرسالة.`);
      logEvent("login_code_issued", phone);
    } catch (e) {
      codes.delete(phone);
      logEvent("login_code_failed", phone, e.message);
    }
    res.json(generic);
  });

  app.post("/api/auth/verify", limit("verify-ip", 30, 10 * 60_000), (req, res) => {
    const phone = normPhone(req.body?.phone);
    const code = String(req.body?.code ?? "").replace(/\D/g, "");
    if (!phone || code.length !== 6) return bad(res, 400, "INPUT", "أدخل الرقم والرمز المكوّن من 6 أرقام.");
    const lock = loginLock.check(phone);
    if (lock.locked) return bad(res, 423, "LOCKED", "الحساب مقفل 15 دقيقة بسبب محاولات خاطئة.", { retryAfter: lock.retryAfter });
    const entry = codes.get(phone);
    const expect = entry && entry.exp > now() ? entry.hash : null;
    const ok = expect !== null && safeEqual(hmac(cfg.sessionSecret, `${phone}:${code}`), expect);
    if (!ok) {
      const f = loginLock.fail(phone);
      logEvent("login_failed", phone, f.locked ? "قُفل 15 دقيقة" : "");
      if (f.locked) { codes.delete(phone); return bad(res, 423, "LOCKED", "5 محاولات خاطئة: قُفل الدخول 15 دقيقة."); }
      return bad(res, 401, "CODE", "الرمز غير صحيح أو منتهي.", { attemptsLeft: f.left });
    }
    if (!botByPhone(phone) || !ACTIVE_STATES.has(stateOf(phone))) {
      return bad(res, 403, "DISCONNECTED", "البوت منفصل ⚠️ — أعد التنصيب", { disconnected: true });
    }
    codes.delete(phone);           // استخدام واحد
    loginLock.reset(phone);
    createSession(req, res, "owner", phone);
    logEvent("login_ok", phone);
    res.json({ ok: true });
  });

  app.post("/api/auth/logout", (req, res) => {
    const s = readSession(req, "owner");
    if (s) { destroySession(s.sid); logEvent("logout", s.phone); }
    clearCookie(req, res, cfg, "ms");
    res.json({ ok: true });
  });

  app.get("/api/me", (req, res) => {
    const s = readSession(req, "owner");
    if (!s) return res.json({ authenticated: false });
    const st = stateOf(s.phone);
    if (!botByPhone(s.phone) || !ACTIVE_STATES.has(st)) {
      destroySession(s.sid); clearCookie(req, res, cfg, "ms");
      return res.json({ authenticated: false, disconnected: true });
    }
    res.json({ authenticated: true, phone: maskPhone(s.phone), state: st });
  });

  // ───────── لوحة المالك ─────────
  app.get("/api/owner/dashboard", requireOwner, (req, res) => {
    const { phone } = req.owner;
    const b = botByPhone(phone);
    res.json({
      phone: maskPhone(phone),
      state: stateOf(phone),
      installedAt: b.createdAt,
      connectedAt: b.connectedAt || null,
      stats: adapter.stats(phone),
      commandsCount: (adapter.commands() || []).reduce((n, c) => n + c.commands.length, 0),
      events: db.events.filter((e) => e.phone === maskPhone(phone)).slice(-50).reverse(),
    });
  });
  app.post("/api/owner/bot/:action", requireOwner, limit("bot-ctl", 10, 60_000, (r) => r.owner.phone), async (req, res) => {
    const { phone } = req.owner;
    if (!["stop", "start"].includes(req.params.action)) return bad(res, 404, "NOT_FOUND", "أمر غير معروف.");
    try {
      await adapter[req.params.action](phone);
      logEvent(`owner_${req.params.action}`, phone);
      hub.publish("dev", "bots", {});
      res.json({ ok: true, state: stateOf(phone) });
    } catch (e) { bad(res, 502, "ADAPTER", "تعذّر تنفيذ الأمر."); }
  });
  app.get("/api/owner/stream", requireOwner, (req, res) =>
    hub.subscribe(req, res, `owner:${req.owner.phone}`, [["status", { status: stateOf(req.owner.phone) }]]));

  // محادثة المطور (للمالك)
  const thread = (phone) => (db.devChats[phone] ||= []);
  app.get("/api/owner/devchat", requireOwner, (req, res) => res.json({ messages: thread(req.owner.phone) }));
  app.post("/api/owner/devchat", requireOwner, limit("devchat", 10, 60_000, (r) => r.owner.phone), (req, res) => {
    const text = cleanText(req.body?.text, 1000);
    if (!text) return bad(res, 400, "INPUT", "اكتب رسالة.");
    const m = { id: store.nextId(), from: "owner", text, ts: now() };
    const t = thread(req.owner.phone); t.push(m); if (t.length > 100) t.splice(0, t.length - 100);
    store.save();
    hub.publish("dev", "devchat", { botId: botId(req.owner.phone), message: m });
    res.json({ ok: true, message: m });
  });

  // الشكاوى الخاصة بالمالك
  app.get("/api/owner/complaints", requireOwner, (req, res) =>
    res.json({ items: db.complaints.filter((c) => c.phone === req.owner.phone).map(publicComplaint).reverse() }));

  // ───────── الشكاوى ─────────
  const publicComplaint = (c) => ({ id: c.id, type: c.type, typeLabel: COMPLAINT_TYPES[c.type], text: c.text, status: c.status, reply: c.reply || null, ts: c.ts, repliedAt: c.repliedAt || null });

  app.get("/api/complaints/types", (req, res) => res.json({ types: COMPLAINT_TYPES }));
  app.post("/api/complaints", limit("complaint-ip", 20, DAY), (req, res) => {
    const type = String(req.body?.type || "");
    const text = cleanText(req.body?.text, 1000);
    const contact = cleanText(req.body?.contact, 40);
    if (!COMPLAINT_TYPES[type]) return bad(res, 400, "TYPE", "اختر نوع الشكوى.");
    if (text.length < 10) return bad(res, 400, "TEXT", "اشرح المشكلة بـ 10 أحرف على الأقل.");
    const owner = readSession(req, "owner");
    const key = owner ? `phone:${owner.phone}` : `ip:${req.ip}`;
    const r = limiter.hit(`complaint-day:${key}`, 3, DAY);
    if (!r.ok) return bad(res, 429, "DAILY", "الحد 3 شكاوى يومياً. حاول غداً.", { retryAfter: r.retryAfter });
    const c = { id: store.nextId(), type, text, contact, phone: owner?.phone || null, status: "new", reply: null, ts: now(), trackKey: randomToken(12) };
    db.complaints.push(c);
    store.save();
    logEvent("complaint_new", owner?.phone, COMPLAINT_TYPES[type]);
    hub.publish("dev", "complaint", { id: c.id });
    res.json({ ok: true, id: c.id, trackKey: c.trackKey });
  });
  // متابعة الشكوى للمشتكي غير المسجل: (id + trackKey) السري.
  app.post("/api/complaints/track", limit("track", 30, 10 * 60_000), (req, res) => {
    const items = Array.isArray(req.body?.items) ? req.body.items.slice(0, 20) : [];
    const out = [];
    for (const it of items) {
      const c = db.complaints.find((x) => x.id === Number(it?.id));
      if (c && safeEqual(String(it?.key ?? ""), c.trackKey)) out.push(publicComplaint(c));
    }
    res.json({ items: out });
  });

  // ───────── الشات الجماعي ─────────
  function chatUser(req) {
    const uid = unsignValue(cfg.sessionSecret, parseCookies(req.headers.cookie).mu);
    return uid ? db.chatUsers[uid] : null;
  }
  const publicMsg = (m) => ({ id: m.id, uid: m.uid, name: m.name, avatar: m.avatar, phone: m.phoneMasked, text: m.text, ts: m.ts, dev: !!m.dev });

  app.post("/api/chat/join", limit("chat-join", 10, 3_600_000), (req, res) => {
    const name = cleanText(req.body?.name, 24);
    if (name.length < 2) return bad(res, 400, "NAME", "الاسم بين 2 و24 حرفاً.");
    if (hasBadWord(name, badWords) || hasLink(name)) return bad(res, 400, "NAME", "الاسم غير مسموح.");
    const avatar = validAvatar(req.body?.avatar);
    if (avatar === null) return bad(res, 400, "AVATAR", "الصورة يجب أن تكون PNG/JPEG/WebP وأقل من 60KB.");
    const owner = readSession(req, "owner");
    let user = chatUser(req);
    if (!user) {
      user = { id: randomToken(9), createdAt: now() };
      db.chatUsers[user.id] = user;
    }
    user.name = name; user.avatar = avatar; user.phoneMasked = owner ? maskPhone(owner.phone) : "";
    store.save();
    setCookie(req, res, cfg, "mu", signValue(cfg.sessionSecret, user.id), 365 * 86400);
    res.json({ ok: true, me: { id: user.id, name: user.name, avatar: user.avatar } });
  });
  app.get("/api/chat/me", (req, res) => {
    const u = chatUser(req);
    res.json(u ? { joined: true, me: { id: u.id, name: u.name, avatar: u.avatar } } : { joined: false });
  });
  app.get("/api/chat/stream", (req, res) => {
    if (!chatUser(req)) return bad(res, 401, "JOIN", "ادخل الاسم أولاً.");
    hub.subscribe(req, res, "chat", [["history", { messages: db.chat.map(publicMsg) }]]);
  });
  app.post("/api/chat/send", (req, res) => {
    const u = chatUser(req);
    if (!u) return bad(res, 401, "JOIN", "ادخل الاسم أولاً.");
    const mute = db.mutes[u.id];
    if (mute !== undefined && (mute === 0 || mute > now())) return bad(res, 403, "MUTED", "تم كتمك من المطور.");
    if (mute !== undefined && mute !== 0) delete db.mutes[u.id];
    const text = cleanText(req.body?.text, 300);
    if (!text) return bad(res, 400, "EMPTY", "اكتب رسالة.");
    const last = chatLast.get(u.id) || 0;
    if (now() - last < 2000) return bad(res, 429, "SLOW", "انتظر ثانيتين بين الرسائل.", { retryAfter: 2 });
    if (hasLink(text)) return bad(res, 400, "LINK", "الروابط ممنوعة في الشات.");
    if (hasBadWord(text, badWords)) return bad(res, 400, "BAD", "الرسالة تحتوي كلمات غير مسموحة.");
    chatLast.set(u.id, now());
    const m = { id: store.nextId(), uid: u.id, name: u.name, avatar: u.avatar, phoneMasked: u.phoneMasked, text, ts: now() };
    db.chat.push(m); if (db.chat.length > 200) db.chat.splice(0, db.chat.length - 200);
    store.save();
    hub.publish("chat", "message", publicMsg(m));
    res.json({ ok: true });
  });

  // ───────── لوحة المطور ─────────
  app.post("/api/dev/login", limit("dev-login-ip", 20, 15 * 60_000), (req, res) => {
    if (!cfg.devPasswordHash) return bad(res, 503, "DISABLED", "لوحة المطور غير مفعّلة (DEV_PASSWORD_HASH غير مضبوط).");
    const lock = devLock.check("global");
    if (lock.locked) return bad(res, 423, "LOCKED", "قُفل دخول المطور مؤقتاً.", { retryAfter: lock.retryAfter });
    if (!verifyPassword(req.body?.password ?? "", cfg.devPasswordHash)) {
      const f = devLock.fail("global");
      logEvent("dev_login_failed", null, f.locked ? "قُفل 15 دقيقة" : "");
      return bad(res, f.locked ? 423 : 401, f.locked ? "LOCKED" : "PASSWORD", "كلمة السر غير صحيحة.");
    }
    devLock.reset("global");
    createSession(req, res, "dev");
    logEvent("dev_login_ok", null);
    res.json({ ok: true });
  });
  app.post("/api/dev/logout", (req, res) => {
    const s = readSession(req, "dev");
    if (s) destroySession(s.sid);
    clearCookie(req, res, cfg, "md");
    res.json({ ok: true });
  });
  app.get("/api/dev/me", (req, res) => res.json({ authenticated: Boolean(readSession(req, "dev")), enabled: Boolean(cfg.devPasswordHash) }));

  const dev = express.Router();
  dev.use(requireDev);
  const botView = (b) => ({ id: b.id, phone: maskPhone(b.phone), state: stateOf(b.phone), createdAt: b.createdAt, connectedAt: b.connectedAt || null });

  dev.get("/stats", (req, res) => {
    const bots = Object.values(db.bots);
    res.json({
      bots: bots.length,
      active: bots.filter((b) => ACTIVE_STATES.has(stateOf(b.phone))).length,
      disconnected: bots.filter((b) => !ACTIVE_STATES.has(stateOf(b.phone)) && b.status !== "pairing").length,
      complaintsNew: db.complaints.filter((c) => c.status === "new").length,
      chatMessages: db.chat.length,
    });
  });
  dev.get("/bots", (req, res) => res.json({ items: Object.values(db.bots).map(botView) }));
  dev.post("/bots/:id/:action", async (req, res) => {
    if (!["stop", "start"].includes(req.params.action)) return bad(res, 404, "NOT_FOUND", "أمر غير معروف.");
    const b = botById(req.params.id);
    if (!b) return bad(res, 404, "NOT_FOUND", "غير موجود.");
    try { await adapter[req.params.action](b.phone); logEvent(`dev_${req.params.action}`, b.phone); res.json({ ok: true, state: stateOf(b.phone) }); }
    catch { bad(res, 502, "ADAPTER", "تعذّر تنفيذ الأمر."); }
  });
  dev.delete("/bots/:id", async (req, res) => {
    const b = botById(req.params.id);
    if (!b) return bad(res, 404, "NOT_FOUND", "غير موجود.");
    try { await adapter.remove(b.phone); } catch { /* نكمل الحذف من السجل */ }
    forceLogout(b.phone, "removed_by_dev");
    delete db.bots[b.phone];
    store.save();
    logEvent("dev_remove_bot", b.phone);
    res.json({ ok: true });
  });

  dev.get("/complaints", (req, res) =>
    res.json({ items: [...db.complaints].reverse().map((c) => ({ ...publicComplaint(c), contact: c.contact, phone: c.phone ? maskPhone(c.phone) : null })) }));
  dev.patch("/complaints/:id", (req, res) => {
    const c = db.complaints.find((x) => x.id === Number(req.params.id));
    if (!c) return bad(res, 404, "NOT_FOUND", "غير موجودة.");
    if (req.body?.status !== undefined) {
      if (!COMPLAINT_STATUS.includes(req.body.status)) return bad(res, 400, "STATUS", "حالة غير صحيحة.");
      c.status = req.body.status;
    }
    if (req.body?.reply !== undefined) {
      const reply = cleanText(req.body.reply, 1000);
      if (reply) { c.reply = reply; c.repliedAt = now(); if (c.status === "new") c.status = "review"; }
    }
    store.save();
    if (c.phone) hub.publish(`owner:${c.phone}`, "complaint", publicComplaint(c));
    logEvent("dev_complaint_update", c.phone, `#${c.id} → ${c.status}`);
    res.json({ ok: true, item: publicComplaint(c) });
  });

  dev.get("/chats", (req, res) => res.json({ items: Object.entries(db.devChats).filter(([, t]) => t.length).map(([phone, t]) => ({
    botId: botId(phone), phone: maskPhone(phone), last: t[t.length - 1], count: t.length })) }));
  dev.get("/chats/:id", (req, res) => {
    const b = botById(req.params.id);
    res.json({ messages: b ? thread(b.phone) : [] });
  });
  dev.post("/chats/:id", (req, res) => {
    const b = botById(req.params.id);
    const text = cleanText(req.body?.text, 1000);
    if (!b || !text) return bad(res, 400, "INPUT", "بيانات غير صحيحة.");
    const m = { id: store.nextId(), from: "dev", text, ts: now() };
    const t = thread(b.phone); t.push(m); if (t.length > 100) t.splice(0, t.length - 100);
    store.save();
    hub.publish(`owner:${b.phone}`, "devchat", m);
    res.json({ ok: true, message: m });
  });

  dev.post("/announcements", (req, res) => {
    const text = cleanText(req.body?.text, 500);
    if (!text) return bad(res, 400, "INPUT", "اكتب نص الإعلان.");
    const a = { id: store.nextId(), text, ts: now() };
    db.announcements.push(a); if (db.announcements.length > 100) db.announcements.shift();
    store.save();
    logEvent("announcement", null, text.slice(0, 40));
    for (const b of Object.values(db.bots)) hub.publish(`owner:${b.phone}`, "announcement", a);
    res.json({ ok: true, item: a });
  });
  dev.delete("/announcements/:id", (req, res) => {
    const i = db.announcements.findIndex((a) => a.id === Number(req.params.id));
    if (i >= 0) db.announcements.splice(i, 1);
    store.save();
    res.json({ ok: true });
  });

  dev.get("/events", (req, res) => res.json({ items: db.events.slice(-300).reverse() }));
  dev.get("/stream", (req, res) => hub.subscribe(req, res, "dev"));

  // إشراف الشات
  dev.get("/chat/messages", (req, res) => res.json({ items: db.chat.slice(-200).reverse() }));
  dev.delete("/chat/:id", (req, res) => {
    const i = db.chat.findIndex((m) => m.id === Number(req.params.id));
    if (i >= 0) { db.chat.splice(i, 1); store.save(); hub.publish("chat", "delete", { id: Number(req.params.id) }); }
    res.json({ ok: true });
  });
  dev.post("/chat/mute", (req, res) => {
    const uid = String(req.body?.uid || "");
    if (!db.chatUsers[uid]) return bad(res, 404, "NOT_FOUND", "مستخدم غير موجود.");
    const minutes = Number(req.body?.minutes ?? 0);
    db.mutes[uid] = minutes > 0 ? now() + minutes * 60_000 : 0;
    store.save();
    logEvent("dev_mute", null, `${db.chatUsers[uid].name} ${minutes > 0 ? minutes + "د" : "دائم"}`);
    res.json({ ok: true });
  });
  dev.delete("/chat/mute/:uid", (req, res) => { delete db.mutes[req.params.uid]; store.save(); res.json({ ok: true }); });
  dev.get("/chat/users", (req, res) => res.json({ items: Object.values(db.chatUsers).slice(-100).map((u) => ({ id: u.id, name: u.name, muted: db.mutes[u.id] !== undefined })) }));
  app.use("/api/dev", dev);

  app.use("/api", (req, res) => bad(res, 404, "NOT_FOUND", "المسار غير موجود."));

  // ───────── الملفات الثابتة (الواجهة) ─────────
  const dist = path.resolve(cfg.distDir);
  if (fs.existsSync(dist)) {
    app.use("/assets", express.static(path.join(dist, "assets"), { immutable: true, maxAge: "1y" }));
    app.use(express.static(dist, { maxAge: "1h", index: false }));
    app.use((req, res) => {
      if (req.method !== "GET") return res.status(404).end();
      res.setHeader("Cache-Control", "no-cache");
      res.sendFile(path.join(dist, "index.html"));
    });
  }

  // ───────── أخطاء ─────────
  app.use((err, req, res, next) => {
    if (err.type === "entity.too.large") return bad(res, 413, "TOO_LARGE", "الطلب كبير جداً.");
    if (err instanceof SyntaxError) return bad(res, 400, "JSON", "JSON غير صالح.");
    console.error("[error]", err);
    bad(res, 500, "INTERNAL", "خطأ داخلي.");
  });

  // تنظيف دوري
  const sweep = setInterval(() => {
    const t = now();
    for (const [k, s] of Object.entries(db.sessions)) if (s.exp < t) delete db.sessions[k];
    for (const [k, w] of watches) if (w.exp < t) { watches.delete(k); hub.close(`watch:${k}`); }
    for (const [k, c] of codes) if (c.exp < t) codes.delete(k);
    store.save();
  }, 60_000);
  sweep.unref();

  return { app, hub, dispose: () => clearInterval(sweep) };
}
