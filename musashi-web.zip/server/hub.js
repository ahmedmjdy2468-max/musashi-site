/** مركز SSE: قنوات مسماة، نبضات keep-alive، وإعادة آخر حدث عند الاشتراك. */
export function createHub() {
  const channels = new Map();
  return {
    subscribe(req, res, channel, initial = []) {
      res.writeHead(200, {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      });
      res.write("retry: 3000\n\n");
      for (const [event, data] of initial) res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      if (!channels.has(channel)) channels.set(channel, new Set());
      channels.get(channel).add(res);
      const beat = setInterval(() => res.write(": ping\n\n"), 25_000);
      req.on("close", () => {
        clearInterval(beat);
        channels.get(channel)?.delete(res);
        if (!channels.get(channel)?.size) channels.delete(channel);
      });
    },
    publish(channel, event, data) {
      const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
      for (const res of channels.get(channel) || []) res.write(payload);
    },
    close(channel) {
      for (const res of channels.get(channel) || []) res.end();
      channels.delete(channel);
    },
    count: (channel) => channels.get(channel)?.size || 0,
  };
}
