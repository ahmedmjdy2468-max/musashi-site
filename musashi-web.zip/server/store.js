import fs from "node:fs";
import path from "node:path";

const EMPTY = () => ({
  bots: {},          // phone -> { id, phone, status, createdAt, connectedAt, updatedAt }
  sessions: {},      // sha256(sid) -> { role, phone?, exp, createdAt }
  complaints: [],
  devChats: {},      // phone -> [{ id, from: 'owner'|'dev', text, ts }]
  announcements: [],
  events: [],
  chat: [],
  chatUsers: {},     // uid -> { id, name, avatar, phoneMasked, createdAt }
  mutes: {},         // uid -> until(ms) | 0 (دائم)
  seq: 1,
});

/** تخزين JSON بسيط وذري. استبدله بـ UltraDB لاحقاً دون تغيير بقية الكود. */
export function createStore(file) {
  let data = EMPTY();
  if (file) {
    try {
      data = { ...EMPTY(), ...JSON.parse(fs.readFileSync(file, "utf8")) };
    } catch (e) {
      if (e.code !== "ENOENT") console.error("[store] تعذّرت قراءة قاعدة البيانات، سيبدأ بقاعدة فارغة:", e.message);
    }
  }
  let timer = null;
  const flush = () => {
    if (!file) return;
    clearTimeout(timer);
    timer = null;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = file + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(data), { mode: 0o600 });
    fs.renameSync(tmp, file);
  };
  return {
    data,
    nextId: () => data.seq++,
    save() {
      if (file && !timer) timer = setTimeout(flush, 250);
    },
    flush,
  };
}
