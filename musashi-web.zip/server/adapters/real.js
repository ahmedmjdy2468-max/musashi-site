import { EventEmitter } from "node:events";

/**
 * المحوّل الحقيقي: يربط الموقع بـ SubBots الموجودة في sub.js.
 *
 * ⚠️ كُتب دون رؤية sub.js (المستودع خاص). الافتراضات أدناه يجب مطابقتها مع الشيفرة الفعلية؛
 * كل سطر عليه "TODO(map)" هو نقطة تحتاج مراجعة. لا تلمس core/meowsab.js.
 *
 * الاستخدام من ملف تشغيل البوت (مثلاً index.js) بعد تهيئة SubBots والبوت الرئيسي:
 *
 *   import { createRealAdapter } from "./web/server/adapters/real.js";
 *   import { startWeb } from "./web/server/start.js";
 *   startWeb({ adapter: createRealAdapter({ SubBots: global.subBots, mainSock: () => global.conn }) });
 *
 * @param {object} deps
 * @param {object} deps.SubBots  المدير؛ يُفترض أنه EventEmitter يصدر pair/ready/close/badSession.
 * @param {() => any} deps.mainSock  دالة تعيد اتصال البوت الرئيسي (Baileys sock) المتصل دائماً.
 * @param {() => Array} [deps.getCommandCategories]  تعيد التصنيفات من modules/ و core/commandDocs.js.
 */
export function createRealAdapter({ SubBots, mainSock, getCommandCategories }) {
  const ee = new EventEmitter();
  const states = new Map();

  // TODO(map): شكل الحمولة. نفترض { phone|number|id, code? }. عدّل الدالة إن اختلف.
  const phoneOf = (p) => String(p?.phone ?? p?.number ?? p?.id ?? p ?? "").replace(/\D/g, "").replace(/^(\d+)@.*/, "$1");

  for (const evt of ["pair", "ready", "close", "badSession"]) {
    SubBots.on?.(evt, (payload) => {
      const phone = phoneOf(payload);
      if (!phone) return;
      if (evt === "ready") states.set(phone, "connected");
      if (evt === "close" || evt === "badSession") states.set(phone, "disconnected");
      ee.emit(evt, { phone, code: payload?.code });
    });
  }

  return Object.assign(ee, {
    state: (phone) => states.get(phone) || (SubBots.isConnected?.(phone) ? "connected" : "none"), // TODO(map): isConnected اختيارية

    async requestPair(phone, code) {
      states.set(phone, "pairing");
      // TODO(map): التوقيع الفعلي لـ SubBots.pariCode (الاسم كما ورد في الوصف). المتوقع: (رقم، كود ثابت).
      await SubBots.pariCode(phone, code);
    },

    // تنظيف الجلسة التالفة فقط، دون لمس بيانات UltraDB.
    async cleanSession(phone) {
      // TODO(map): استدعِ دالة تنظيف مجلد جلسة هذا الرقم في sub.js إن وُجدت. اتركها فارغة إن كان التنظيف تلقائياً.
      await SubBots.cleanSession?.(phone);
    },

    // الرسالة تمر عبر البوت الرئيسي دائماً وليس الفرعي.
    async sendMain(phone, text) {
      const sock = mainSock();
      if (!sock) throw new Error("البوت الرئيسي غير متصل");
      await sock.sendMessage(`${phone}@s.whatsapp.net`, { text });
    },

    async stop(phone) { await SubBots.stop?.(phone); states.set(phone, "stopped"); },   // TODO(map)
    async start(phone) { await SubBots.start?.(phone); states.set(phone, "connected"); }, // TODO(map)
    async remove(phone) { await SubBots.remove?.(phone); states.delete(phone); },        // TODO(map)

    stats: (phone) => SubBots.stats?.(phone) ?? null, // TODO(map): اختياري
    commands: () => getCommandCategories?.() ?? [],
  });
}
