import { EventEmitter } from "node:events";

/**
 * محوّل تجريبي في الذاكرة لتشغيل الموقع واختباره دون واتساب.
 * يحاكي أحداث sub.js: 'pair' و'ready' و'close' و'badSession'.
 * واجهة المحوّل (يجب أن يطبّقها real.js أيضاً) موثقة في README.md.
 */
export function createMockAdapter({ autoPair = true } = {}) {
  const ee = new EventEmitter();
  const bots = new Map(); // phone -> 'pairing'|'connected'|'stopped'|'disconnected'
  const outbox = [];
  const log = (...a) => process.env.NODE_ENV !== "test" && console.log("[mock-bot]", ...a);

  return Object.assign(ee, {
    outbox,
    state: (phone) => bots.get(phone) || "none",
    async requestPair(phone, code) {
      bots.set(phone, "pairing");
      log(`pair ${phone} code=${code}`);
      if (autoPair) setTimeout(() => ee.emit("pair", { phone, code }), 150);
    },
    async cleanSession(phone) { log("cleanSession", phone); },
    async sendMain(phone, text) {
      outbox.push({ phone, text });
      log(`رسالة إلى ${phone}:\n${text}`);
    },
    async stop(phone) { if (bots.get(phone) === "connected") bots.set(phone, "stopped"); },
    async start(phone) { if (bots.get(phone) === "stopped") bots.set(phone, "connected"); },
    async remove(phone) { bots.delete(phone); },
    stats: () => null,
    commands: () => [
      { id: "general", icon: "📘", title: "الأوامر العامة", commands: [{ name: ".menu", desc: "قائمة الأوامر (بيانات تجريبية)" }] },
      { id: "groups", icon: "👥", title: "إدارة المجموعات", commands: [{ name: ".kick", desc: "طرد عضو (بيانات تجريبية)" }] },
    ],
    // مساعدات للاختبار / التجربة اليدوية
    simulateReady(phone) { bots.set(phone, "connected"); ee.emit("ready", { phone }); },
    simulateClose(phone) { bots.set(phone, "disconnected"); ee.emit("close", { phone }); },
    simulateBadSession(phone) { bots.set(phone, "disconnected"); ee.emit("badSession", { phone }); },
    lastCode(phone) { return [...outbox].reverse().find((m) => m.phone === phone)?.text.match(/\d{6}/)?.[0]; },
  });
}
