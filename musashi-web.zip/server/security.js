import crypto from "node:crypto";

export const sha256 = (s) => crypto.createHash("sha256").update(s).digest("hex");
export const hmac = (secret, s) => crypto.createHmac("sha256", secret).update(s).digest("base64url");
export const randomToken = (bytes = 24) => crypto.randomBytes(bytes).toString("base64url");

export function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) {
    crypto.timingSafeEqual(ba, ba); // وقت ثابت تقريباً
    return false;
  }
  return crypto.timingSafeEqual(ba, bb);
}

export function signValue(secret, value) {
  return `${value}.${hmac(secret, value)}`;
}
export function unsignValue(secret, signed) {
  if (typeof signed !== "string") return null;
  const i = signed.lastIndexOf(".");
  if (i < 1) return null;
  const value = signed.slice(0, i);
  return safeEqual(signed.slice(i + 1), hmac(secret, value)) ? value : null;
}

export function parseCookies(header = "") {
  const out = {};
  for (const part of header.split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* تجاهل */ }
  }
  return out;
}

export function setCookie(req, res, cfg, name, value, maxAgeSec) {
  const secure = cfg.cookieSecure === "auto" ? req.secure : cfg.cookieSecure;
  const parts = [`${name}=${encodeURIComponent(value)}`, "Path=/", "HttpOnly", "SameSite=Lax", `Max-Age=${maxAgeSec}`];
  if (secure) parts.push("Secure");
  const prev = res.getHeader("Set-Cookie");
  const list = prev ? [].concat(prev) : [];
  list.push(parts.join("; "));
  res.setHeader("Set-Cookie", list);
}
export const clearCookie = (req, res, cfg, name) => setCookie(req, res, cfg, name, "", 0);

/** حد معدّل بنافذة منزلقة (في الذاكرة). */
export function createLimiter() {
  const hits = new Map();
  const timer = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (!v.some((t) => now - t < v.win)) hits.delete(k);
  }, 60_000);
  timer.unref();
  return {
    hit(key, limit, windowMs) {
      const now = Date.now();
      const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
      arr.win = windowMs;
      if (arr.length >= limit) {
        hits.set(key, arr);
        return { ok: false, retryAfter: Math.ceil((windowMs - (now - arr[0])) / 1000) };
      }
      arr.push(now);
      hits.set(key, arr);
      return { ok: true };
    },
  };
}

/** قفل المحاولات الخاطئة: N محاولات ثم قفل لمدة محددة. */
export function createLockout(max = 5, lockMs = 15 * 60_000) {
  const m = new Map();
  return {
    check(key) {
      const e = m.get(key);
      if (e?.until && e.until > Date.now()) return { locked: true, retryAfter: Math.ceil((e.until - Date.now()) / 1000) };
      if (e?.until) m.delete(key);
      return { locked: false };
    },
    fail(key) {
      const e = m.get(key) || { fails: 0 };
      e.fails++;
      if (e.fails >= max) { e.until = Date.now() + lockMs; e.fails = 0; }
      m.set(key, e);
      return e.until ? { locked: true } : { locked: false, left: max - e.fails };
    },
    reset: (key) => m.delete(key),
  };
}

// صيغة كلمة سر المطور: scrypt$N$saltB64$hashB64
export function hashPassword(password) {
  const N = 16384, salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 32, { N });
  return `scrypt$${N}$${salt.toString("base64")}$${hash.toString("base64")}`;
}
export function verifyPassword(password, stored) {
  try {
    const [alg, N, salt, hash] = String(stored).split("$");
    if (alg !== "scrypt") return false;
    const got = crypto.scryptSync(String(password), Buffer.from(salt, "base64"), 32, { N: Number(N) });
    const want = Buffer.from(hash, "base64");
    return got.length === want.length && crypto.timingSafeEqual(got, want);
  } catch { return false; }
}
