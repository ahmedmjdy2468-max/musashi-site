const AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";

export function normPhone(v) {
  if (typeof v !== "string") return null;
  let d = v.replace(/[٠-٩]/g, (c) => String(AR_DIGITS.indexOf(c))).replace(/[\s\-()+.]/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  return /^\d{8,15}$/.test(d) ? d : null;
}
export const maskPhone = (p) => `+${p.slice(0, 3)}***${p.slice(-3)}`;

export function cleanText(v, max) {
  if (typeof v !== "string") return "";
  return v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F‎‏‪-‮]/g, "").replace(/[ \t]+/g, " ").trim().slice(0, max);
}

const URL_RE = /(https?:\/\/|www\.|wa\.me|chat\.whatsapp|t\.me|discord\.gg|\b[a-z0-9-]+\.(com|net|org|io|me|gg|ly|xyz|ru|info|app|dev|co|tk|cc|ws|link|click)\b)/i;
export const hasLink = (s) => URL_RE.test(s.replace(/\s*\.\s*/g, "."));

export function normalizeArabic(s) {
  return s.toLowerCase()
    .replace(/[ً-ٰٟـ]/g, "")
    .replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه")
    .replace(/[^\p{L}\p{N}\s]/gu, " ");
}
export function hasBadWord(text, words) {
  const n = " " + normalizeArabic(text).replace(/\s+/g, " ") + " ";
  const squashed = n.replace(/(.)\1+/g, "$1");
  return words.some((w) => n.includes(` ${w} `) || squashed.includes(` ${w} `));
}

export function validAvatar(v) {
  if (typeof v !== "string" || !v) return "";
  if (v.length > 90_000) return null;
  return /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v) ? v : null;
}
