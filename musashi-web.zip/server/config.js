import crypto from "node:crypto";

const bool = (v, d = false) => (v === undefined ? d : /^(1|true|yes|on)$/i.test(String(v)));

export function loadConfig(env = process.env, overrides = {}) {
  const prod = env.NODE_ENV === "production";
  const cfg = {
    prod,
    port: Number(env.PORT || 3000),
    host: env.HOST || "0.0.0.0",
    maxBots: Number(env.MAX_BOTS || 50),
    sessionSecret: env.SESSION_SECRET || "",
    pairCode: env.SUB_PAIR_CODE || "",
    devPasswordHash: env.DEV_PASSWORD_HASH || "",
    channelUrl: env.CHANNEL_URL || "",
    adapter: env.BOT_ADAPTER || "mock",
    dataFile: env.DATA_FILE === undefined ? "./data/db.json" : env.DATA_FILE,
    trustProxy: env.TRUST_PROXY === undefined ? false : env.TRUST_PROXY === "true" ? true : Number.isNaN(Number(env.TRUST_PROXY)) ? env.TRUST_PROXY : Number(env.TRUST_PROXY),
    cookieSecure: env.COOKIE_SECURE === undefined ? "auto" : bool(env.COOKIE_SECURE),
    allowedOrigins: (env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean),
    distDir: env.DIST_DIR || "./dist",
    extraBadWordsFile: env.BAD_WORDS_FILE || "",
    ...overrides,
  };

  const problems = [];
  if (!/^[A-Za-z0-9]{8}$/.test(cfg.pairCode)) {
    problems.push("SUB_PAIR_CODE يجب أن يكون 8 حروف/أرقام بالضبط (بدون شرطات).");
  }
  if (cfg.sessionSecret.length < 32) {
    if (prod) problems.push("SESSION_SECRET مطلوب (32 حرفاً على الأقل) في وضع الإنتاج.");
    else {
      cfg.sessionSecret = crypto.randomBytes(32).toString("hex");
      cfg.ephemeralSecret = true;
    }
  }
  if (prod && cfg.adapter === "mock") problems.push("BOT_ADAPTER=mock ممنوع في الإنتاج. استخدم real.");
  if (problems.length) {
    const err = new Error("إعدادات غير صحيحة:\n- " + problems.join("\n- "));
    err.problems = problems;
    throw err;
  }
  return cfg;
}
