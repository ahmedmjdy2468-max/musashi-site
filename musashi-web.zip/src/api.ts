// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type J = any;

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public data: J) {
    super(message);
  }
}

export async function api<T = J>(method: string, url: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      credentials: "same-origin",
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, "NETWORK", "تعذّر الاتصال بالخادم.", {});
  }
  let data: J = {};
  try { data = await res.json(); } catch { /* فارغ */ }
  if (!res.ok) throw new ApiError(res.status, data.error || "ERROR", data.message || "حدث خطأ غير متوقع.", data);
  return data as T;
}
export const get = <T = J>(u: string) => api<T>("GET", u);
export const post = <T = J>(u: string, b: unknown = {}) => api<T>("POST", u, b);
export const patch = <T = J>(u: string, b: unknown) => api<T>("PATCH", u, b);
export const del = <T = J>(u: string) => api<T>("DELETE", u);

/** اشتراك SSE مع إغلاق نظيف. */
export function listen(url: string, handlers: Record<string, (d: J) => void>, onError?: () => void): () => void {
  const es = new EventSource(url, { withCredentials: true });
  for (const [name, fn] of Object.entries(handlers)) {
    es.addEventListener(name, (e) => { try { fn(JSON.parse((e as MessageEvent).data)); } catch { /* تجاهل */ } });
  }
  es.onerror = () => onError?.();
  return () => es.close();
}

export const fmtDate = (ts?: number | null) =>
  ts ? new Date(ts).toLocaleString("ar", { dateStyle: "medium", timeStyle: "short" }) : "—";
export const fmtTime = (ts: number) => new Date(ts).toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" });
