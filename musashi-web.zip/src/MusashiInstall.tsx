import { useEffect, useRef, useState, type ChangeEvent, type CSSProperties } from "react";
import "./musashi.css";

type Destination =
  | "install"
  | "dashboard"
  | "commands"
  | "group"
  | "complaints"
  | "developer"
  | "channel"
  | "customize"
  | "devConsole";

type Palette = {
  id: string;
  label: string;
  color: string;
  wash: string;
};

const destinations: { id: Destination; icon: string; label: string }[] = [
  { id: "install", icon: "🤖", label: "تنصيب البوت" },
  { id: "dashboard", icon: "🎛", label: "لوحة التحكم" },
  { id: "commands", icon: "📜", label: "الأوامر" },
  { id: "group", icon: "💬", label: "الشات الجماعي" },
  { id: "complaints", icon: "📮", label: "الشكاوى" },
  { id: "developer", icon: "👨‍💻", label: "محادثة المطور" },
  { id: "channel", icon: "📢", label: "قناة البوت" },
  { id: "customize", icon: "🎨", label: "تخصيص الموقع" },
  { id: "devConsole", icon: "🔐", label: "لوحة المطور" },
];

const palettes: Palette[] = [
  { id: "wisteria", label: "ويستيريا", color: "#c5a0ff", wash: "#553c75" },
  { id: "amethyst", label: "جمشت", color: "#d1a7f2", wash: "#694c75" },
  { id: "saffron", label: "زعفران", color: "#e2bd75", wash: "#765b2c" },
  { id: "jade", label: "يشم", color: "#8ac2a6", wash: "#345b4a" },
  { id: "indigo", label: "نيلي", color: "#9cafe0", wash: "#3f4a70" },
  { id: "rose", label: "ساكورا", color: "#df9ab5", wash: "#754355" },
  { id: "copper", label: "نحاس", color: "#d89775", wash: "#774a38" },
  { id: "ice", label: "ضباب", color: "#9cc8d1", wash: "#3c626b" },
  { id: "plum", label: "برقوق", color: "#ca9dc5", wash: "#694766" },
  { id: "moon", label: "قمر", color: "#c3c5df", wash: "#55576e" },
];

const scenes = [
  { id: "sunset", label: "غروب الساموراي", src: `${import.meta.env.BASE_URL}images/musashi/sunset-samurai.jpg` },
  { id: "autumn", label: "ورق الخريف", src: `${import.meta.env.BASE_URL}images/musashi/autumn-samurai.jpg` },
  { id: "sky", label: "سماء مفتوحة", src: `${import.meta.env.BASE_URL}images/musashi/sky-samurai.jpg` },
  { id: "forest", label: "غابة هادئة", src: `${import.meta.env.BASE_URL}images/musashi/forest-samurai.jpg` },
  { id: "crow", label: "غراب المساء", src: `${import.meta.env.BASE_URL}images/musashi/samurai-crow.jpg` },
];

const commandCategories = [
  { title: "الأوامر العامة", description: "معلومات البوت، المساعدة، اللغة، وطرق الاستخدام الأساسية." },
  { title: "إدارة المجموعات", description: "أدوات الإشراف، إعدادات المجموعة، وتنظيم الأعضاء." },
  { title: "الوسائط والترفيه", description: "أوامر الصور، الملصقات، الألعاب، والمحتوى الترفيهي." },
  { title: "التنزيلات", description: "واجهات تنزيل الوسائط المدعومة — التوفر يُحدّد بعد الربط." },
  { title: "الذكاء الاصطناعي", description: "محادثة ومساعدة ذكية، وفق الخدمات المفعّلة في نسختك." },
  { title: "أوامر المالك", description: "إدارة الجلسة، إعادة الربط، والتشخيص — للمالك فقط." },
];

function EyeScene() {
  return (
    <div className="mu-hero-art" aria-hidden="true">
      <svg viewBox="0 0 390 250" role="img">
        <defs>
          <linearGradient id="mu-katana" x1="0" x2="1">
            <stop offset="0" stopColor="#d6c7e5" stopOpacity=".15" />
            <stop offset=".48" stopColor="#f2e8fa" stopOpacity=".8" />
            <stop offset="1" stopColor="#c8a967" stopOpacity=".4" />
          </linearGradient>
        </defs>
        <circle className="mu-sun" cx="239" cy="91" r="62" />
        <circle className="mu-art-gold" cx="239" cy="91" r="73" strokeDasharray="1 8" />
        <path className="mu-art-muted" d="M18 198c54-21 88-20 125-2m-116 12c48-16 83-16 114-4" />
        <path className="mu-art-line" d="M23 66c8-8 15-8 22 0-7 8-14 8-22 0Zm39 18c6-6 11-6 17 0-6 6-11 6-17 0Zm249-39c8-8 15-8 22 0-7 8-14 8-22 0Z" />
        <path className="mu-art-muted" d="M321 175c-18-5-27-14-32-30 18 4 27 13 32 30Zm9 8c13-12 25-15 41-10-11 14-24 18-41 10Z" />
        <path className="mu-art-fill" d="M99 232c10-33 28-54 53-67 10-12 14-26 13-43l18-9 19 12c-1 24 8 38 21 47 18 14 30 33 35 60H99Z" />
        <path className="mu-art-line" d="M163 122c-11-14-14-28-10-42 4 9 9 14 16 16m36 24c14-12 22-26 25-42-9 5-17 7-25 7m-37 27c14 8 29 9 44 2m-43 13c17 6 33 4 49-7" />
        <path className="mu-art-muted" d="M156 96c-17-13-28-29-33-49 14 10 24 18 34 21m-23-1c-14-5-25-14-32-28 15 4 26 10 36 19m93 3c17-13 28-29 33-49-14 10-24 18-34 21m23-1c14-5 25-14 32-28-15 4-26 10-36 19" />
        <path className="mu-art-gold" d="M143 102c14-10 28-14 43-11m16 0c15-4 29 0 43 11M184 128l-4 11 12 3 11-5-6-9" />
        <path className="mu-art-muted" d="M183 148c7 5 15 5 23 0m-32 28c13 7 27 7 42 0" />
        <path d="M138 100c13-7 25-9 38-6m32 0c12-3 24-1 36 6" fill="none" stroke="rgba(24,17,31,.8)" strokeWidth="5" strokeLinecap="round" />
        <path d="M112 229 320 52" stroke="url(#mu-katana)" strokeWidth="3" strokeLinecap="round" />
        <path className="mu-art-gold" d="m174 181 16 17m-5-23 16 17" />
        <path className="mu-art-muted" d="M80 147c6 3 11 3 16-1m189 52c8-3 14-8 18-15" />
        <circle className="star" cx="91" cy="45" r="1.6" /><circle className="star" cx="289" cy="33" r="1.2" />
        <circle className="star" cx="353" cy="108" r="1.5" /><circle className="star" cx="54" cy="124" r="1" />
      </svg>
      <span className="mu-hero-caption">A QUIET EDGE · MUSASHI V5</span>
    </div>
  );
}

function Toggle({
  checked,
  onClick,
  label,
}: {
  checked: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      className="mu-toggle"
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={onClick}
    >
      <span />
    </button>
  );
}

function EmptyState({
  symbol,
  title,
  description,
}: {
  symbol: string;
  title: string;
  description: string;
}) {
  return (
    <div className="mu-empty">
      <div className="mu-empty-symbol">{symbol}</div>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  );
}

export function MusashiInstall() {
  const [destination, setDestination] = useState<Destination>("install");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [phone, setPhone] = useState("");
  const [showSteps, setShowSteps] = useState(false);
  const [palette, setPalette] = useState("wisteria");
  const [mode, setMode] = useState<"night" | "day">("night");
  const [clickSound, setClickSound] = useState(false);
  const [brightness, setBrightness] = useState(82);
  const [sceneId, setSceneId] = useState("sunset");
  const [uploadScene, setUploadScene] = useState("");
  const [search, setSearch] = useState("");
  const [protectedPreview, setProtectedPreview] = useState(false);
  const [toast, setToast] = useState("");
  const [musicPlaying, setMusicPlaying] = useState(false);
  const [musicVolume, setMusicVolume] = useState(0.14);
  const [preferencesLoaded, setPreferencesLoaded] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const clickAudioRef = useRef<AudioContext | null>(null);
  const uploadUrlRef = useRef<string | null>(null);
  const toastTimer = useRef<number | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("musashi-visual-preferences");
      if (saved) {
        const prefs = JSON.parse(saved) as {
          palette?: string;
          mode?: "night" | "day";
          clickSound?: boolean;
          brightness?: number;
          sceneId?: string;
        };
        if (palettes.some((item) => item.id === prefs.palette)) setPalette(prefs.palette!);
        if (prefs.mode === "night" || prefs.mode === "day") setMode(prefs.mode);
        if (typeof prefs.clickSound === "boolean") setClickSound(prefs.clickSound);
        if (typeof prefs.brightness === "number") setBrightness(Math.max(35, Math.min(100, prefs.brightness)));
        if (scenes.some((item) => item.id === prefs.sceneId)) setSceneId(prefs.sceneId!);
      }
    } catch {
      localStorage.removeItem("musashi-visual-preferences");
    } finally {
      setPreferencesLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (!preferencesLoaded) return;
    localStorage.setItem(
      "musashi-visual-preferences",
      JSON.stringify({ palette, mode, clickSound, brightness, sceneId }),
    );
  }, [palette, mode, clickSound, brightness, sceneId, preferencesLoaded]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = musicVolume;
  }, [musicVolume]);

  useEffect(
    () => () => {
      if (uploadUrlRef.current) URL.revokeObjectURL(uploadUrlRef.current);
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      if (clickAudioRef.current) void clickAudioRef.current.close();
    },
    [],
  );

  const activeScene = scenes.find((scene) => scene.id === sceneId)?.src ?? scenes[0].src;
  const sceneStyle = {
    "--scene": `url("${uploadScene || activeScene}")`,
    "--scene-opacity": `${brightness / 100}`,
  } as CSSProperties;

  const showToast = (message: string) => {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 3400);
  };

  const playClickSound = () => {
    if (!clickSound) return;
    try {
      const context = clickAudioRef.current ?? new window.AudioContext();
      clickAudioRef.current = context;
      if (context.state === "suspended") void context.resume();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const now = context.currentTime;
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(510, now);
      gain.gain.setValueAtTime(0.018, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.045);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start(now);
      oscillator.stop(now + 0.05);
    } catch {
      // Browser audio can be unavailable; the preference still remains saved.
    }
  };

  const goTo = (id: Destination) => {
    setDestination(id);
    setDrawerOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const uploadBackground = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    if (!file) return;
    if (uploadUrlRef.current) URL.revokeObjectURL(uploadUrlRef.current);
    const nextUrl = URL.createObjectURL(file);
    uploadUrlRef.current = nextUrl;
    setUploadScene(nextUrl);
    showToast("تم تطبيق الخلفية على معاينتك المحلية.");
  };

  const toggleMusic = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (musicPlaying) {
      audio.pause();
      setMusicPlaying(false);
      return;
    }
    try {
      await audio.play();
      setMusicPlaying(true);
    } catch {
      showToast("ملف الموسيقى غير متاح حالياً في هذه المعاينة.");
    }
  };

  const pageTitle = destinations.find((item) => item.id === destination)?.label ?? "تنصيب البوت";
  const filteredCategories = commandCategories.filter((category) =>
    `${category.title} ${category.description}`.includes(search.trim()),
  );

  return (
    <div className="mu" data-palette={palette} data-mode={mode === "night" ? "dark" : "light"} onClickCapture={playClickSound}>
      <div className="mu-shell">
        <button
          className={`mu-drawer-backdrop ${drawerOpen ? "open" : ""}`}
          type="button"
          aria-label="إغلاق القائمة"
          onClick={() => setDrawerOpen(false)}
        />
        <aside className={`mu-sidebar ${drawerOpen ? "open" : ""}`} aria-label="التنقل الرئيسي">
          <div className="mu-brand">
            <div className="mu-brand-mark">⚔</div>
            <div>
              <div className="mu-brand-title">MUSASHI <span>BOT</span></div>
              <div className="mu-brand-tag">لوحة تحكم البوت الفرعي</div>
            </div>
          </div>
          <div className="mu-preview-label"><span>معاينة تصميم · v5.0</span><i /></div>
          <div className="mu-nav-label">مسارات الواجهة</div>
          <nav className="mu-nav">
            {destinations.map((item) => (
              <button
                key={item.id}
                className="mu-nav-item"
                type="button"
                aria-current={destination === item.id ? "page" : undefined}
                onClick={() => goTo(item.id)}
              >
                <span className="mu-nav-icon">{item.icon}</span>
                <span>{item.label}</span>
                {destination === item.id && <i className="mu-nav-current" />}
              </button>
            ))}
          </nav>
          <div className="mu-sidebar-foot">
            <strong>واجهة استعراضية فقط</strong>
            <span>لا توجد جلسة واتساب أو بيانات حية.</span>
          </div>
        </aside>

        <main className="mu-main">
          <header className="mu-topbar">
            <button className="mu-menu-button" type="button" aria-label="فتح القائمة" onClick={() => setDrawerOpen(true)}>
              <span aria-hidden="true">☰</span>
            </button>
            <div className="mu-crumb"><span>مساحة المالك</span>　/　<b>{pageTitle}</b></div>
            <div className="mu-top-actions">
              <div className="mu-live-pill"><i /> البيانات الحية: بانتظار الربط</div>
              <div className="mu-preview-pill"><span>✦</span> DESIGN PREVIEW</div>
            </div>
          </header>

          {destination === "install" && (
            <section className="mu-page">
              <div className="mu-page-head">
                <div>
                  <div className="mu-eyebrow">MUSASHI BOT · SUB-BOT SETUP</div>
                  <h1>ابدأ من هنا، بخطوة واضحة.</h1>
                  <p>ربط البوت الفرعي يبدأ برقمك — ولا يحدث شيء حتى تؤكد الربط من واتساب.</p>
                </div>
                <div className="mu-note"><span className="mu-note-symbol">PREVIEW</span><span><b>معاينة تصميم فقط.</b> لا يتم إرسال الرقم أو بدء جلسة من هنا.</span></div>
              </div>

              <div className="mu-hero" style={sceneStyle}>
                <div className="mu-hero-copy">
                  <div className="mu-eyebrow">THE QUIET EDGE · V5.0</div>
                  <h2 className="mu-hero-title">جهّز اتصالك.<br /><em>ثم دع البوت يتكلم.</em></h2>
                  <p>مساحة عربية لإعداد البوت الفرعي ومتابعته. الإقران، الحالة، والإحصاءات الحقيقية ستظهر بعد تكامل البوت.</p>
                  <div className="mu-slogan">سَبْقِ حَسْمَك بِرَقْمِك بُوْتَك الفَرْعِي</div>
                  <div className="mu-hero-actions">
                    <button className="mu-btn-primary" type="button" onClick={() => { setShowSteps(true); document.getElementById("mu-connect-card")?.scrollIntoView({ behavior: "smooth", block: "center" }); }}>
                      ابدأ تجهيز الربط <span aria-hidden="true">←</span>
                    </button>
                    <button className="mu-btn-secondary" type="button" onClick={() => goTo("dashboard")}>استكشف لوحة التحكم</button>
                  </div>
                </div>
                <EyeScene />
              </div>

              <div className="mu-install-grid">
                <section id="mu-connect-card" className="mu-panel mu-panel-inner">
                  <div className="mu-panel-title">
                    <h2><span className="mu-section-icon">◈</span> ربط رقم واتساب</h2>
                    <small>خطوات الإقران · لا اتصال فعلي</small>
                  </div>
                  <div className="mu-progress" aria-label="تسلسل عملية الربط">
                    <div className={`mu-progress-item ${showSteps ? "active" : ""}`}><span className="mu-progress-dot">01</span><span>رقمك</span></div>
                    <div className="mu-progress-line" />
                    <div className={`mu-progress-item ${showSteps ? "active" : ""}`}><span className="mu-progress-dot">02</span><span>رمز الربط</span></div>
                    <div className="mu-progress-line" />
                    <div className={`mu-progress-item ${showSteps ? "active" : ""}`}><span className="mu-progress-dot">03</span><span>تأكيد واتساب</span></div>
                  </div>
                  <label className="mu-field-label" htmlFor="mu-phone">رقم الهاتف المرتبط بحساب واتساب</label>
                  <div className="mu-phone-wrap">
                    <input
                      className="mu-phone-input"
                      id="mu-phone"
                      inputMode="tel"
                      autoComplete="tel"
                      placeholder="أدخل رقم واتساب هنا"
                      value={phone}
                      onChange={(event) => setPhone(event.currentTarget.value)}
                    />
                    <button className="mu-btn-primary" type="button" onClick={() => { setShowSteps(true); showToast("هذه معاينة فقط؛ لم يُرسل الرقم ولم يبدأ اتصال."); }}>
                      تجهيز الإقران
                    </button>
                  </div>
                  <div className="mu-code-slot">
                    <div><strong>رمز الإقران</strong><small>سيظهر هنا فقط بعد اتصال البوت بالخادم.</small></div>
                    <span className="mu-code-lock" aria-label="لا يوجد رمز في المعاينة">⌑ ····</span>
                  </div>
                  <p className="mu-small-print">لا تعرض المعاينة رمزاً أو حالة اتصال. ستأتي حالة المالك ورمز الإقران من البوت بعد التكامل.</p>
                  {showSteps && (
                    <div className="mu-inline-alert">
                      <b>المسار معروض للتصميم فقط.</b> لم يتم إرسال الرقم أو إنشاء جلسة. عند التكامل سيُستبدل هذا الموضع برمز حقيقي عند توفره.
                    </div>
                  )}
                  <div className="mu-actions-row" style={{ marginTop: 13 }}>
                    <button className="mu-btn-quiet" type="button" onClick={() => setShowSteps((value) => !value)}>
                      {showSteps ? "إخفاء الإرشادات" : "عرض خطوات الإقران"}
                    </button>
                  </div>
                </section>

                <div className="mu-panel mu-panel-inner">
                  <div className="mu-panel-title">
                    <h2><span className="mu-section-icon">⌁</span> خطوات واتساب</h2>
                    <small>تظهر هنا بعد التكامل</small>
                  </div>
                  <div className="mu-step-list">
                    <div className="mu-step"><span className="mu-step-index">1</span><span>افتح واتساب على الهاتف الذي أدخلت رقمه.</span></div>
                    <div className="mu-step"><span className="mu-step-index">2</span><span>من <b>الإعدادات</b> أو قائمة ⋮ اختر <b>الأجهزة المرتبطة</b>.</span></div>
                    <div className="mu-step"><span className="mu-step-index">3</span><span>اضغط <b>ربط جهاز</b> ثم <b>الربط برقم الهاتف بدلاً من ذلك</b>.</span></div>
                    <div className="mu-step"><span className="mu-step-index">4</span><span>أدخل رمز الإقران الذي سيعرضه البوت بعد الاتصال. لا يوجد رمز في هذه المعاينة.</span></div>
                  </div>
                  <p className="mu-small-print">قد تختلف أسماء القوائم قليلاً بين إصدارات واتساب.</p>
                </div>
              </div>

              <div className="mu-panel mu-panel-inner" style={{ marginTop: 15 }}>
                <div className="mu-panel-title"><h2>مرجع الحالات</h2><small>دلالات بصرية فقط — لا تمثل حالة حالية</small></div>
                <div className="mu-status-grid">
                  <div className="mu-state-chip pair"><strong>بانتظار الإقران</strong><small>سيظهر الرمز بعد اتصال البوت.</small></div>
                  <div className="mu-state-chip ready"><strong>جاهز</strong><small>يتطلب جلسة مؤكدة من واتساب.</small></div>
                  <div className="mu-state-chip disconnected"><strong>غير متصل</strong><small>لا توجد جلسة فعالة في هذه المعاينة.</small></div>
                  <div className="mu-state-chip bad"><strong>جلسة غير صالحة</strong><small>تُعرض عند اكتشاف مشكلة بعد التكامل.</small></div>
                </div>
              </div>
              <div className="mu-footer"><span><b>MUSASHI ⚔️ BOT</b> · مساحة الإعداد</span><span>الإحصاءات، أعداد الأوامر، رموز الإقران، وحالة المالك ستأتي من البوت بعد التكامل.</span></div>
            </section>
          )}

          {destination === "dashboard" && (
            <section className="mu-page">
              <div className="mu-page-head">
                <div><div className="mu-eyebrow">OWNER OVERVIEW</div><h1>لوحة التحكم</h1><p>ملخص واضح لما سيصبح متاحاً بعد ربط البوت.</p></div>
                <div className="mu-preview-pill">بانتظار تكامل البوت</div>
              </div>
              <div className="mu-grid-3 mu-dashboard-stats">
                {[["حالة الجلسة", "— — —", "ستُقرأ من البوت بعد الربط.", "◉"], ["الأوامر المتاحة", "— —", "يُحمّل العدد ديناميكياً.", "⌘"], ["آخر نشاط", "— — —", "لا يوجد سجل حي في المعاينة.", "↗"]].map(([label, value, foot, icon]) => (
                  <div className="mu-panel mu-stat" key={label}><span className="mu-stat-icon">{icon}</span><span className="mu-stat-label">{label}</span><strong className="mu-stat-value">{value}</strong><span className="mu-stat-foot">{foot}</span></div>
                ))}
              </div>
              <div className="mu-panel mu-panel-inner">
                <div className="mu-panel-title"><h2>إجراءات الاتصال</h2><small>معاينة بلا اتصال فعلي</small></div>
                <div className="mu-callout">لا يوجد بوت متصل في صفحة التصميم. إعادة التشغيل وإعادة الإقران تصبحان متاحتين بعد الربط فقط.</div>
                <div className="mu-actions-row" style={{ marginTop: 14 }}>
                  <button className="mu-btn-secondary" type="button" onClick={() => showToast("إعادة التشغيل غير متاحة قبل تكامل البوت.")}>↻　إعادة تشغيل البوت</button>
                  <button className="mu-btn-secondary" type="button" onClick={() => goTo("install")}>⌁　الانتقال إلى الإقران</button>
                </div>
              </div>
              <div className="mu-panel mu-panel-inner" style={{ marginTop: 14 }}>
                <div className="mu-panel-title"><h2>سجل الأحداث</h2><small>يظهر بعد التكامل</small></div>
                <EmptyState symbol="⌁" title="لا توجد أحداث للعرض" description="ستظهر محاولات الإقران وتغييرات حالة البوت هنا بعد اتصال حقيقي." />
              </div>
              <div className="mu-footer"><span><b>بيانات معلّقة</b> · لا توجد أرقام أو حالة مباشرة في هذا التصميم.</span><span>DESIGN PREVIEW · v5.0</span></div>
            </section>
          )}

          {destination === "commands" && (
            <section className="mu-page">
              <div className="mu-page-head">
                <div><div className="mu-eyebrow">COMMAND LIBRARY</div><h1>دليل الأوامر</h1><p>تصنيفات استكشافية؛ القائمة والأعداد تُحمّل من البوت بعد التكامل.</p></div>
                <label className="mu-search"><span aria-hidden="true">⌕</span><input value={search} onChange={(event) => setSearch(event.currentTarget.value)} placeholder="ابحث في التصنيفات" aria-label="ابحث في تصنيفات الأوامر" /></label>
              </div>
              <div className="mu-note"><span className="mu-note-symbol">DYNAMIC</span><span><b>عدد الأوامر: يُحمّل لاحقاً.</b> لا تحتوي المعاينة على أعداد ثابتة أو أوامر تشغيل فعلية.</span></div>
              <div className="mu-categories">
                {filteredCategories.map((category, index) => (
                  <article className="mu-panel mu-category" key={category.title}>
                    <div className="mu-category-head"><h3><span className="mu-section-icon">{["⌘", "◈", "✧", "↓", "◎", "⚿"][index % 6]}</span>{category.title}</h3><span className="mu-pending-count">— / لاحقاً</span></div>
                    <p>{category.description}</p>
                    <div className="mu-category-more">الأوامر: تُحمّل ديناميكياً من نسخة البوت المتصلة.</div>
                  </article>
                ))}
                {filteredCategories.length === 0 && <div className="mu-panel" style={{ gridColumn: "1 / -1" }}><EmptyState symbol="⌕" title="لا توجد تصنيفات مطابقة" description="جرّب عبارة بحث أخرى." /></div>}
              </div>
              <div className="mu-footer"><span>التصنيفات توضيحية؛ لا تُنفذ أوامر من هذه الواجهة.</span><span><b>العدد الحقيقي بعد الربط</b></span></div>
            </section>
          )}

          {destination === "group" && (
            <section className="mu-page">
              <div className="mu-page-head"><div><div className="mu-eyebrow">GROUP CHAT</div><h1>الشات الجماعي</h1><p>مساحة مجتمع البوت — لا رسائل أو أعضاء حقيقيين في المعاينة.</p></div><div className="mu-preview-pill">قيد الإعداد</div></div>
              <div className="mu-grid-2">
                <div className="mu-panel"><EmptyState symbol="◌" title="لا توجد رسائل للعرض" description="لن تظهر محادثات حقيقية قبل تكامل خدمة البوت وربط صلاحيات المجموعة." /></div>
                <div className="mu-panel mu-feature-card"><div className="mu-eyebrow">COMMUNITY GUIDELINES</div><h3 style={{ marginTop: 8 }}>مجتمع هادئ، وحدود واضحة.</h3><p>ستُعرض قواعد المجموعة وإعدادات الإشراف هنا. لا يوجد رابط دعوة أو مجتمع فعلي ضمن هذه المعاينة.</p><div className="mu-actions-row" style={{ marginTop: 14 }}><button className="mu-btn-quiet" type="button" onClick={() => showToast("لا يوجد رابط مجتمع في التصميم التجريبي.")}>تفاصيل المجموعة</button></div></div>
              </div>
              <div className="mu-panel mu-panel-inner" style={{ marginTop: 14 }}><div className="mu-panel-title"><h2>حالة المجموعة</h2><small>بانتظار ربط البوت</small></div><div className="mu-log-row"><span>الرسائل</span><span className="mu-log-placeholder">بانتظار البيانات</span></div><div className="mu-log-row"><span>قواعد المشاركة</span><span className="mu-log-placeholder">بانتظار إعداد المالك</span></div></div>
              <div className="mu-footer"><span><b>معاينة فقط</b> · لا يتم تحميل أو إرسال محادثات.</span><span>MUSASHI BOT</span></div>
            </section>
          )}

          {destination === "complaints" && (
            <section className="mu-page">
              <div className="mu-page-head"><div><div className="mu-eyebrow">SUPPORT INBOX</div><h1>صندوق الشكاوى</h1><p>صندوق خاص للمالك، مع حالة فارغة صريحة حتى يتوفر مصدر البيانات.</p></div><div className="mu-preview-pill">صندوق تجريبي</div></div>
              <div className="mu-panel"><EmptyState symbol="✉" title="لا توجد شكاوى للعرض" description="ستصل البلاغات الحقيقية إلى هنا بعد تكامل البوت. لا توجد رسائل أو أسماء مستخدمين في هذه الصفحة." /></div>
              <div className="mu-grid-2" style={{ marginTop: 14 }}>
                <div className="mu-panel mu-feature-card"><h3>مسار المعالجة</h3><p>بلاغ جديد ← مراجعة المالك ← رد أو إغلاق. تتغير الحالات بعد توفر واجهة البوت فقط.</p></div>
                <div className="mu-panel mu-feature-card"><h3>خصوصية واضحة</h3><p>تفاصيل المرسل والمحادثة مخفية في التصميم. الوصول الفعلي يظل مقيداً بصلاحية المالك.</p></div>
              </div>
              <div className="mu-footer"><span>عدد الشكاوى: <b>بانتظار البيانات</b></span><span>لا يوجد اتصال بخادم أو حسابات.</span></div>
            </section>
          )}

          {destination === "developer" && (
            <section className="mu-page">
              <div className="mu-page-head"><div><div className="mu-eyebrow">DEVELOPER CONTACT</div><h1>محادثة المطور</h1><p>قناة دعم مصممة بهدوء. الإرسال غير متصل في هذا العرض.</p></div><div className="mu-preview-pill">غير متصل</div></div>
              <div className="mu-panel mu-panel-inner">
                <div className="mu-panel-title"><h2>تواصل خاص</h2><small>لا رسائل أو حسابات فعلية</small></div>
                <EmptyState symbol="⌁" title="لا توجد محادثة بعد" description="لن تظهر محادثات حقيقية في المعاينة. عند التكامل سيُعرَض سجل الدعم الخاص بك هنا." />
                <form className="mu-chat-compose" onSubmit={(event) => { event.preventDefault(); showToast("المراسلة غير متاحة في المعاينة؛ لم يتم إرسال أي شيء."); }}>
                  <textarea aria-label="مسودة رسالة للمطور" placeholder="اكتب مسودة — لن تُرسل من هذه المعاينة" />
                  <button className="mu-btn-primary" type="submit">إرسال بعد التكامل</button>
                </form>
                <p className="mu-small-print">زر الإرسال يوضح المسار فقط. لن تُحفظ المسودة أو تُرسل إلى أي جهة.</p>
              </div>
              <div className="mu-footer"><span><b>قناة دعم مقترحة</b> · لا حساب مطور أو رابط حقيقي.</span><span>PREVIEW ONLY</span></div>
            </section>
          )}

          {destination === "channel" && (
            <section className="mu-page">
              <div className="mu-page-head"><div><div className="mu-eyebrow">OFFICIAL CHANNEL</div><h1>قناة البوت</h1><p>مساحة إعلانات وإصدارات بتصميم قابل للربط لاحقاً.</p></div><div className="mu-preview-pill">لا يوجد رابط مباشر</div></div>
              <div className="mu-hero" style={{ ...sceneStyle, minHeight: 240 }}>
                <div className="mu-hero-copy"><div className="mu-eyebrow">FIELD NOTES</div><h2 className="mu-hero-title">إشعار واحد.<br /><em>حين يكون هناك ما يستحق.</em></h2><p>الإصدارات والتنبيهات الرسمية ستُعرض هنا بعد إضافة مصدر القناة.</p></div>
                <EyeScene />
              </div>
              <div className="mu-panel" style={{ marginTop: 14 }}><EmptyState symbol="⌁" title="لا توجد إعلانات بعد" description="هذه القناة تصميمية فقط؛ لم تُضف روابط أو منشورات أو حسابات حقيقية." /></div>
              <div className="mu-footer"><span>الإشعارات <b>بانتظار المصدر</b></span><span>MUSASHI BOT · v5.0</span></div>
            </section>
          )}

          {destination === "customize" && (
            <section className="mu-page">
              <div className="mu-page-head"><div><div className="mu-eyebrow">VISUAL ARMOURY</div><h1>تخصيص الموقع</h1><p>غيّر مظهر معاينتك. تحفظ التفضيلات محلياً على هذا الجهاز فقط.</p></div><div className="mu-preview-pill">تفضيلات محلية</div></div>
              <div className="mu-settings-layout">
                <div>
                  <section className="mu-panel mu-setting-section">
                    <h2>ألوان الواجهة</h2><p>عشر نغمات مستوحاة من مواد وألوان اليابان القديمة.</p>
                    <div className="mu-palette-grid">
                      {palettes.map((item) => (
                        <button className="mu-palette" type="button" key={item.id} aria-pressed={palette === item.id} onClick={() => setPalette(item.id)}>
                          <span className="mu-swatch" style={{ background: `linear-gradient(130deg,${item.color},${item.wash})` }} />
                          <small>{item.label}</small>
                        </button>
                      ))}
                    </div>
                  </section>
                  <section className="mu-panel mu-setting-section">
                    <h2>مشهد الخلفية</h2><p>اختر مشهداً جاهزاً أو استعرض صورة من جهازك كمعاينة.</p>
                    <div className="mu-scene-grid">
                      {scenes.map((scene) => (
                        <button
                          key={scene.id}
                          className="mu-scene"
                          type="button"
                          aria-pressed={!uploadScene && sceneId === scene.id}
                          style={{ backgroundImage: `linear-gradient(0deg,rgba(13,9,17,.22),transparent),url("${scene.src}")` }}
                          onClick={() => { setUploadScene(""); setSceneId(scene.id); }}
                        ><span>{scene.label}</span></button>
                      ))}
                      <label className="mu-scene-upload">＋<br />رفع صورة للمعاينة<input type="file" accept="image/*" onChange={uploadBackground} /></label>
                    </div>
                    {uploadScene && <div className="mu-small-print">تُعرض الصورة المرفوعة في هذه الجلسة فقط.</div>}
                    <label className="mu-range-row"><span>سطوع المشهد</span><input type="range" min="35" max="100" value={brightness} onChange={(event) => setBrightness(Number(event.currentTarget.value))} /><span className="mu-range-value">{brightness}%</span></label>
                  </section>
                </div>
                <div>
                  <section className="mu-panel mu-setting-section">
                    <h2>تفضيلات العرض</h2><p>إعدادات صغيرة، فرقها واضح.</p>
                    <div className="mu-toggle-row"><div className="mu-toggle-text"><strong>وضع النهار</strong><small>التبديل بين ليل هادئ ونهار فاتح</small></div><Toggle checked={mode === "day"} onClick={() => setMode((value) => value === "night" ? "day" : "night")} label="تبديل الوضع النهاري" /></div>
                    <div className="mu-toggle-row"><div className="mu-toggle-text"><strong>صوت النقر</strong><small>تفضيل محفوظ؛ الصوت غير مفعّل في المعاينة</small></div><Toggle checked={clickSound} onClick={() => setClickSound((value) => !value)} label="تفعيل تفضيل صوت النقر" /></div>
                    <div className="mu-toggle-row"><div className="mu-toggle-text"><strong>حفظ التفضيلات</strong><small>{preferencesLoaded ? "محفوظة محلياً على هذا الجهاز" : "جارٍ تحميل تفضيلات الجهاز"}</small></div><span style={{ color: "var(--success)", fontSize: 10 }}>● محلي</span></div>
                  </section>
                  <section className="mu-panel mu-setting-section">
                    <div className="mu-panel-title"><div><h2>موسيقى هادئة</h2><p style={{ margin: "4px 0 0" }}>لا يبدأ التشغيل تلقائياً.</p></div><span className="mu-section-icon">♫</span></div>
                    <div className="mu-audio-card">
                      <div className="mu-audio-meta"><div className="mu-album-mark">月</div><div><strong>Pan's Labyrinth Lullaby</strong><small>Juliana Chahayed</small><small>Pan's Labyrinth Lullaby - Single · 2025 · Alternative Folk</small></div></div>
                      <div className="mu-audio-controls">
                        <button type="button" onClick={toggleMusic}>{musicPlaying ? "إيقاف مؤقت" : "تشغيل"}</button>
                        <label className="mu-range-row" style={{ flex: 1, margin: 0 }}><span>الصوت</span><input type="range" min="0" max="0.35" step="0.01" value={musicVolume} onChange={(event) => setMusicVolume(Number(event.currentTarget.value))} /><span className="mu-range-value">{Math.round(musicVolume * 100)}%</span></label>
                      </div>
                      <p className="mu-music-note">تشغيل يدوي وبمستوى منخفض. مصدر الصوت مرفق بالمعاينة فقط.</p>
                    </div>
                  </section>
                </div>
              </div>
              <div className="mu-footer"><span><b>تخصيص محفوظ</b> محلياً — لا يُرسل إلى خادم.</span><span>المشهد، السطوع، اللون، والوضع محفوظة.</span></div>
            </section>
          )}

          {destination === "devConsole" && (
            <section className="mu-page">
              <div className="mu-page-head"><div><div className="mu-eyebrow">RESTRICTED ACCESS</div><h1>لوحة المطور</h1><p>ضوابط إدارية محمية. المعاينة لا تتصل بأي حساب أو أسرار.</p></div><div className="mu-preview-pill">طبقة حماية مرئية</div></div>
              <div className="mu-protected">
                <div className="mu-protected-lock">⌑</div>
                <div className="mu-eyebrow">OWNER / DEVELOPER ONLY</div>
                <h2>هذه المنطقة محمية بصلاحيات.</h2>
                <p>إدارة المالكين، الإعلانات، وأدوات الصيانة ستتطلب تحققاً حقيقياً بعد التكامل. لا تعرض صفحة التصميم أسماء مالكين أو مفاتيح أو رموز وصول.</p>
                <div className="mu-protected-list"><span>إدارة صلاحيات المالك</span><span>صندوق الشكاوى الخاص</span><span>نشر الإعلانات</span></div>
                <button className="mu-btn-primary" type="button" onClick={() => setProtectedPreview((value) => !value)}>{protectedPreview ? "إخفاء عناصر المعاينة" : "استعراض عناصر التحكم المحمية"}</button>
              </div>
              {protectedPreview && (
                <div className="mu-panel mu-panel-inner" style={{ marginTop: 14 }}>
                  <div className="mu-panel-title"><h2>معاينة الأدوات المقفلة</h2><small>تعطيل مقصود · لا تغييرات فعلية</small></div>
                  <div className="mu-disabled-controls">
                    <div className="mu-grid-2">
                      <div className="mu-feature-card" style={{ border: "1px solid var(--line)", borderRadius: 10 }}><h3>قائمة المالكين</h3><p>تُحمّل بعد تحقق المطور. لا توجد حسابات معروضة.</p></div>
                      <div className="mu-feature-card" style={{ border: "1px solid var(--line)", borderRadius: 10 }}><h3>إرسال إعلان</h3><p>تتطلب صلاحية موثقة ومصدر إعلان حقيقياً.</p></div>
                    </div>
                    <div className="mu-actions-row" style={{ marginTop: 12 }}><button className="mu-btn-secondary" type="button" disabled>إضافة مالك</button><button className="mu-btn-secondary" type="button" disabled>نشر إعلان</button></div>
                  </div>
                  <div className="mu-callout" style={{ marginTop: 14 }}>التحكم الحقيقي غير متاح هنا؛ هذه الشاشة لا تحفظ أسراراً ولا تنفذ أوامر.</div>
                </div>
              )}
              <div className="mu-footer"><span><b>صلاحيات إدارية</b> · محمية وغير متصلة.</span><span>لا أسرار · لا حسابات · لا API</span></div>
            </section>
          )}
        </main>
      </div>
      {toast && <div className="mu-toast" role="status">{toast}</div>}
      <audio
        ref={audioRef}
        className="mu-hidden-audio"
        src={`${import.meta.env.BASE_URL}images/musashi/pans-labyrinth-lullaby.mp3`}
        preload="none"
        onEnded={() => setMusicPlaying(false)}
      />
    </div>
  );
}
