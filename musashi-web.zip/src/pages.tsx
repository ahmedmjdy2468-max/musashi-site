import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { ApiError, get, post, patch, del, listen, fmtDate, fmtTime, type J } from "./api";
import type { Owner } from "./useOwner";

type Common = { owner: Owner; goTo: (id: string) => void; toast: (m: string) => void };

const errMsg = (e: unknown) => (e instanceof ApiError ? e.message : "حدث خطأ غير متوقع.");

function Empty({ symbol, title, text }: { symbol: string; title: string; text: string }) {
  return (
    <div className="mu-empty"><div className="mu-empty-symbol">{symbol}</div><h3>{title}</h3><p>{text}</p></div>
  );
}
function Head({ eyebrow, title, text, aside }: { eyebrow: string; title: string; text: string; aside?: ReactNode }) {
  return (
    <div className="mu-page-head">
      <div><div className="mu-eyebrow">{eyebrow}</div><h1>{title}</h1><p>{text}</p></div>
      {aside}
    </div>
  );
}
function Err({ text }: { text: string }) {
  return text ? <div className="mu-form-error" role="alert">{text}</div> : null;
}

/* ───────────── التنصيب ───────────── */

export function SiteStats() {
  const [s, setS] = useState<J | null>(null);
  useEffect(() => { get("/api/stats").then(setS).catch(() => setS(null)); }, []);
  const v = (n?: number) => (s ? String(n) : "—");
  return (
    <div className="mu-grid-3 mu-dashboard-stats" style={{ marginTop: 15 }}>
      <div className="mu-panel mu-stat"><span className="mu-stat-icon">◈</span><span className="mu-stat-label">أماكن متاحة</span><strong className="mu-stat-value live">{v(s?.available)}</strong><span className="mu-stat-foot">من أصل {s ? s.total : "—"}</span></div>
      <div className="mu-panel mu-stat"><span className="mu-stat-icon">◉</span><span className="mu-stat-label">بوتات مفعّلة</span><strong className="mu-stat-value live">{v(s?.active)}</strong><span className="mu-stat-foot">متصلة الآن</span></div>
      <div className="mu-panel mu-stat"><span className="mu-stat-icon">⚠</span><span className="mu-stat-label">بوتات منفصلة</span><strong className="mu-stat-value live">{v(s?.disconnected)}</strong><span className="mu-stat-foot">تحتاج إعادة تنصيب</span></div>
    </div>
  );
}

type Phase = "idle" | "starting" | "waiting" | "pair" | "ready" | "active" | "closed";

export function ConnectPanel({ goTo, toast, onPhase }: Common & { onPhase: (p: Phase) => void }) {
  const [phone, setPhone] = useState("");
  const [phase, setPhaseRaw] = useState<Phase>("idle");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const stop = useRef<null | (() => void)>(null);
  const setPhase = (p: Phase) => { setPhaseRaw(p); onPhase(p); };
  useEffect(() => () => stop.current?.(), []);

  const start = async (e: FormEvent) => {
    e.preventDefault();
    setError(""); setCode(""); stop.current?.();
    setPhase("starting");
    try {
      const r = await post("/api/install", { phone });
      setPhase("waiting");
      stop.current = listen(`/api/install/events?t=${encodeURIComponent(r.watch)}`, {
        pair: (d) => { setCode(d.code); setPhase("pair"); },
        ready: () => { setPhase("ready"); stop.current?.(); },
        close: () => { setPhase("closed"); },
      });
    } catch (err) {
      if (err instanceof ApiError && err.code === "ACTIVE") { setPhase("active"); return; }
      setPhase("idle"); setError(errMsg(err));
    }
  };

  const busy = phase === "starting" || phase === "waiting" || phase === "pair";
  return (
    <section id="mu-connect-card" className="mu-panel mu-panel-inner">
      <div className="mu-panel-title"><h2><span className="mu-section-icon">◈</span> ربط رقم واتساب</h2><small>تنصيب واحد لكل رقم</small></div>
      <form onSubmit={start}>
        <label className="mu-field-label" htmlFor="mu-phone">رقم الهاتف المرتبط بحساب واتساب (بصيغة دولية)</label>
        <div className="mu-phone-wrap">
          <input className="mu-phone-input" id="mu-phone" inputMode="tel" autoComplete="tel" dir="ltr" placeholder="9689xxxxxxx"
            value={phone} onChange={(e) => setPhone(e.currentTarget.value)} disabled={busy} required />
          <button className="mu-btn-primary" type="submit" disabled={busy || !phone.trim()}>{phase === "starting" ? "جارٍ التجهيز…" : "تجهيز الإقران"}</button>
        </div>
      </form>
      <Err text={error} />

      {phase === "active" && <div className="mu-state-banner ready"><strong>البوت مفعّل ✅</strong><span>هذا الرقم منصَّب ومتصل. لا حاجة لتنصيب جديد.</span><button className="mu-btn-secondary" type="button" onClick={() => goTo("dashboard")}>ادخل لوحة التحكم</button></div>}
      {phase === "closed" && <div className="mu-state-banner warn"><strong>انقطع الاتصال أثناء الإقران ⚠️</strong><span>اضغط «تجهيز الإقران» للمحاولة من جديد.</span></div>}
      {phase === "ready" && <div className="mu-state-banner ready"><strong>✅ تم ربط بوتك بنجاح</strong><span>يمكنك الآن الدخول إلى لوحة التحكم.</span><button className="mu-btn-primary" type="button" onClick={() => goTo("dashboard")}>ادخل لوحة التحكم</button></div>}

      <div className={`mu-code-slot ${phase === "pair" ? "live" : ""}`}>
        <div>
          <strong>رمز الإقران</strong>
          <small>{phase === "pair" ? "أدخله في واتساب الآن." : phase === "waiting" ? "بانتظار رمز الإقران من البوت…" : "يظهر هنا بعد تجهيز الإقران."}</small>
        </div>
        <span className="mu-code-value" dir="ltr" aria-live="polite">{phase === "pair" ? code : "········"}</span>
        {phase === "pair" && <button className="mu-btn-quiet" type="button" onClick={() => { void navigator.clipboard?.writeText(code); toast("تم نسخ الرمز."); }}>نسخ</button>}
      </div>
    </section>
  );
}

export const installSteps = (
  <div className="mu-step-list">
    <div className="mu-step"><span className="mu-step-index">1</span><span>افتح واتساب على الهاتف الذي أدخلت رقمه.</span></div>
    <div className="mu-step"><span className="mu-step-index">2</span><span>اذهب إلى <b>الأجهزة المرتبطة</b> من الإعدادات أو قائمة ⋮.</span></div>
    <div className="mu-step"><span className="mu-step-index">3</span><span>اضغط <b>ربط جهاز</b> ثم <b>الربط برقم الهاتف بدلاً من ذلك</b>.</span></div>
    <div className="mu-step"><span className="mu-step-index">4</span><span>أدخل <b>رمز الإقران</b> الظاهر في الموقع (8 حروف/أرقام).</span></div>
  </div>
);

/* ───────────── لوحة التحكم + دخول المالك ───────────── */

function LoginFlow({ owner, goTo }: { owner: Owner; goTo: Common["goTo"] }) {
  const [phone, setPhone] = useState("");
  const [step, setStep] = useState<1 | 2>(1);
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const [disc, setDisc] = useState(false);

  const request = async (e: FormEvent) => {
    e.preventDefault(); setError(""); setBusy(true);
    try { const r = await post("/api/auth/request", { phone }); setInfo(r.message); setStep(2); }
    catch (err) { setError(errMsg(err)); }
    setBusy(false);
  };
  const verify = async (e: FormEvent) => {
    e.preventDefault(); setError(""); setBusy(true);
    try { await post("/api/auth/verify", { phone, code }); await owner.refresh(); }
    catch (err) {
      if (err instanceof ApiError && err.data?.disconnected) setDisc(true);
      setError(errMsg(err) + (err instanceof ApiError && err.data?.attemptsLeft != null ? ` (متبقي ${err.data.attemptsLeft} محاولات)` : ""));
    }
    setBusy(false);
  };

  return (
    <div className="mu-panel mu-panel-inner mu-login">
      {owner.forced && <div className="mu-state-banner warn"><strong>البوت منفصل ⚠️ — أعد التنصيب</strong><span>تم إخراجك من اللوحة. بياناتك محفوظة، وبعد إعادة التنصيب تدخل بكود جديد.</span><button className="mu-btn-primary" type="button" onClick={() => goTo("install")}>إعادة التنصيب</button></div>}
      <div className="mu-panel-title"><h2><span className="mu-section-icon">🔐</span> دخول صاحب البوت</h2><small>مرة واحدة والجلسة باقية</small></div>
      {step === 1 ? (
        <form onSubmit={request}>
          <label className="mu-field-label" htmlFor="mu-login-phone">رقمك المسجّل عند التنصيب</label>
          <div className="mu-phone-wrap">
            <input className="mu-phone-input" id="mu-login-phone" dir="ltr" inputMode="tel" placeholder="9689xxxxxxx" value={phone} onChange={(e) => setPhone(e.currentTarget.value)} required />
            <button className="mu-btn-primary" type="submit" disabled={busy || !phone.trim()}>إرسال الكود</button>
          </div>
          <p className="mu-small-print">سيصلك كود من 6 أرقام على واتساب عبر البوت الرئيسي.</p>
        </form>
      ) : (
        <form onSubmit={verify}>
          <div className="mu-inline-alert">{info}</div>
          <label className="mu-field-label" htmlFor="mu-login-code">كود التحقق (6 أرقام)</label>
          <div className="mu-phone-wrap">
            <input className="mu-phone-input mu-otp" id="mu-login-code" dir="ltr" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="••••••" value={code} onChange={(e) => setCode(e.currentTarget.value.replace(/\D/g, ""))} required />
            <button className="mu-btn-primary" type="submit" disabled={busy || code.length !== 6}>دخول</button>
          </div>
          <div className="mu-actions-row" style={{ marginTop: 10 }}>
            <button className="mu-btn-quiet" type="button" onClick={() => { setStep(1); setCode(""); setError(""); }}>تغيير الرقم</button>
            {disc && <button className="mu-btn-secondary" type="button" onClick={() => goTo("install")}>إعادة التنصيب</button>}
          </div>
        </form>
      )}
      <Err text={error} />
    </div>
  );
}

const STATE_LABEL: Record<string, string> = { connected: "متصل ✅", stopped: "متوقف ⏸", disconnected: "منفصل ⚠️", pairing: "قيد الإقران", none: "غير معروف" };

export function DashboardPage({ owner, goTo, toast }: Common) {
  const [d, setD] = useState<J | null>(null);
  const [ann, setAnn] = useState<J[]>([]);
  const authed = Boolean(owner.me?.authenticated);

  const load = () => get("/api/owner/dashboard").then(setD).catch(() => { void owner.refresh(); });
  useEffect(() => { if (authed) void load(); else setD(null); }, [authed, owner.me?.state]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { get("/api/announcements").then((r) => setAnn(r.items)).catch(() => {}); }, []);
  useEffect(() => {
    if (!authed) return;
    return listen("/api/owner/stream", { announcement: (a) => setAnn((l) => [a, ...l]) });
  }, [authed]);

  const act = async (a: "stop" | "start") => {
    try { await post(`/api/owner/bot/${a}`); toast(a === "stop" ? "تم إيقاف البوت." : "تم تشغيل البوت."); await owner.refresh(); await load(); }
    catch (e) { toast(errMsg(e)); }
  };

  return (
    <section className="mu-page">
      <Head eyebrow="OWNER OVERVIEW" title="لوحة التحكم" text="حالة بوتك وإحصاءاته وسجل أحداثه."
        aside={authed ? <button className="mu-btn-quiet" type="button" onClick={() => void owner.logout()}>تسجيل الخروج</button> : undefined} />
      {ann[0] && <div className="mu-note" style={{ marginBottom: 14 }}><span className="mu-note-symbol">📢</span><span><b>إعلان المطور:</b> {ann[0].text}</span></div>}

      {owner.loading ? <div className="mu-panel mu-panel-inner"><Empty symbol="…" title="جارٍ التحميل" text="" /></div>
        : !authed ? <LoginFlow owner={owner} goTo={goTo} />
        : (
          <>
            <div className="mu-grid-3 mu-dashboard-stats">
              <div className="mu-panel mu-stat"><span className="mu-stat-icon">◉</span><span className="mu-stat-label">حالة البوت</span><strong className={`mu-stat-value live st-${d?.state}`}>{d ? STATE_LABEL[d.state] ?? d.state : "—"}</strong><span className="mu-stat-foot" dir="ltr">{d?.phone}</span></div>
              <div className="mu-panel mu-stat"><span className="mu-stat-icon">⌘</span><span className="mu-stat-label">الأوامر المتاحة</span><strong className="mu-stat-value live">{d ? d.commandsCount : "—"}</strong><span className="mu-stat-foot">من البوت مباشرة</span></div>
              <div className="mu-panel mu-stat"><span className="mu-stat-icon">↗</span><span className="mu-stat-label">آخر اتصال</span><strong className="mu-stat-value live small">{d ? fmtDate(d.connectedAt) : "—"}</strong><span className="mu-stat-foot">تنصيب: {d ? fmtDate(d.installedAt) : "—"}</span></div>
            </div>
            {d?.stats && <div className="mu-panel mu-panel-inner" style={{ marginBottom: 14 }}><div className="mu-panel-title"><h2>إحصاءات البوت</h2></div><div className="mu-kv">{Object.entries(d.stats).map(([k, v]) => <div key={k}><span>{k}</span><b>{String(v)}</b></div>)}</div></div>}
            <div className="mu-panel mu-panel-inner">
              <div className="mu-panel-title"><h2>التحكم</h2><small>إيقاف مؤقت دون فقد الربط</small></div>
              <div className="mu-actions-row">
                {d?.state === "stopped"
                  ? <button className="mu-btn-primary" type="button" onClick={() => void act("start")}>▶　تشغيل البوت</button>
                  : <button className="mu-btn-secondary" type="button" onClick={() => void act("stop")}>⏸　إيقاف البوت</button>}
                <button className="mu-btn-quiet" type="button" onClick={() => goTo("developer")}>👨‍💻　تواصل مع المطور</button>
              </div>
              <p className="mu-small-print">إن انفصل البوت (تسجيل خروج من واتساب مثلاً) ستُخرَج من اللوحة تلقائياً، ثم أعد التنصيب وادخل بكود جديد وبياناتك محفوظة.</p>
            </div>
            <div className="mu-panel mu-panel-inner" style={{ marginTop: 14 }}>
              <div className="mu-panel-title"><h2>سجل الأحداث</h2><small>آخر {d?.events?.length ?? 0}</small></div>
              {d?.events?.length ? (
                <ul className="mu-log">{d.events.map((e: J) => <li key={e.id}><time>{fmtDate(e.ts)}</time><span>{EVENT_AR[e.type] ?? e.type}</span>{e.detail && <small>{e.detail}</small>}</li>)}</ul>
              ) : <Empty symbol="⌁" title="لا توجد أحداث بعد" text="ستظهر هنا محاولات الدخول وتغييرات حالة البوت." />}
            </div>
          </>
        )}
    </section>
  );
}

export const EVENT_AR: Record<string, string> = {
  install_requested: "طلب تنصيب", reinstall_requested: "طلب إعادة تنصيب", pair_code_shown: "عُرض كود الإقران", bot_ready: "تم ربط البوت ✅",
  login_code_issued: "أُصدر كود دخول", login_ok: "تسجيل دخول", login_failed: "محاولة دخول خاطئة", logout: "تسجيل خروج",
  forced_logout: "خروج إجباري (انفصال)", owner_stop: "إيقاف البوت", owner_start: "تشغيل البوت", complaint_new: "شكوى جديدة",
  install_failed: "فشل التنصيب", login_code_failed: "فشل إرسال الكود", dev_login_ok: "دخول المطور", dev_login_failed: "محاولة خاطئة لدخول المطور",
  dev_stop: "إيقاف من المطور", dev_start: "تشغيل من المطور", dev_remove_bot: "حذف بوت", dev_complaint_update: "تحديث شكوى",
  announcement: "إعلان جديد", dev_mute: "كتم مستخدم",
};

/* ───────────── الأوامر ───────────── */

export function CommandsPage() {
  const [data, setData] = useState<J | null>(null);
  const [open, setOpen] = useState<J | null>(null);
  const [q, setQ] = useState("");
  const [err, setErr] = useState("");
  useEffect(() => { get("/api/commands").then(setData).catch((e) => setErr(errMsg(e))); }, []);
  const cats = useMemo(() => (data?.categories ?? []).filter((c: J) => c.title.includes(q.trim())), [data, q]);
  const show = async (id: string) => { try { setOpen(await get(`/api/commands/${id}`)); } catch (e) { setErr(errMsg(e)); } };

  return (
    <section className="mu-page">
      <Head eyebrow="COMMAND LIBRARY" title="دليل الأوامر" text={data ? `${data.total} أمراً في ${data.categories.length} تصنيفات.` : "جارٍ التحميل…"}
        aside={<label className="mu-search"><span aria-hidden="true">⌕</span><input value={q} onChange={(e) => setQ(e.currentTarget.value)} placeholder="ابحث في التصنيفات" aria-label="ابحث في تصنيفات الأوامر" /></label>} />
      <Err text={err} />
      {open ? (
        <div className="mu-panel mu-panel-inner">
          <div className="mu-panel-title"><h2>{open.icon} {open.title} <small>({open.count})</small></h2><button className="mu-btn-quiet" type="button" onClick={() => setOpen(null)}>رجوع</button></div>
          <ul className="mu-cmd-list">{open.commands.map((c: J) => <li key={c.name}><code dir="ltr">{c.name}</code><span>{c.desc || "—"}</span></li>)}</ul>
        </div>
      ) : (
        <div className="mu-categories">
          {cats.map((c: J) => (
            <button type="button" className="mu-panel mu-category mu-category-btn" key={c.id} onClick={() => void show(c.id)}>
              <div className="mu-category-head"><h3><span className="mu-section-icon">{c.icon}</span>{c.title}</h3><span className="mu-count">{c.count}</span></div>
              <div className="mu-category-more">اضغط لعرض الأوامر ووصفها</div>
            </button>
          ))}
          {data && cats.length === 0 && <div className="mu-panel" style={{ gridColumn: "1 / -1" }}><Empty symbol="⌕" title="لا توجد تصنيفات" text="لا نتائج مطابقة، أو لم تُحمَّل الأوامر من البوت بعد." /></div>}
        </div>
      )}
    </section>
  );
}

/* ───────────── الشات الجماعي ───────────── */

async function shrinkAvatar(file: File): Promise<string> {
  const bmp = await createImageBitmap(file);
  const c = document.createElement("canvas"); c.width = c.height = 96;
  const x = c.getContext("2d")!; const s = Math.min(bmp.width, bmp.height);
  x.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, 96, 96);
  return c.toDataURL("image/jpeg", 0.8);
}
const Avatar = ({ src, name }: { src?: string; name: string }) =>
  src ? <img className="mu-avatar" src={src} alt="" /> : <span className="mu-avatar ph">{name.slice(0, 1)}</span>;

export function GroupChatPage() {
  const [me, setMe] = useState<J | null | undefined>(undefined);
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState("");
  const [msgs, setMsgs] = useState<J[]>([]);
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const end = useRef<HTMLDivElement>(null);

  useEffect(() => { get("/api/chat/me").then((r) => setMe(r.joined ? r.me : null)).catch(() => setMe(null)); }, []);
  useEffect(() => {
    if (!me) return;
    return listen("/api/chat/stream", {
      history: (d) => setMsgs(d.messages),
      message: (m) => setMsgs((l) => [...l.slice(-199), m]),
      delete: (d) => setMsgs((l) => l.filter((m) => m.id !== d.id)),
    });
  }, [me]);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);

  const join = async (e: FormEvent) => {
    e.preventDefault(); setErr("");
    try { const r = await post("/api/chat/join", { name, avatar }); setMe(r.me); } catch (x) { setErr(errMsg(x)); }
  };
  const send = async (e: FormEvent) => {
    e.preventDefault(); const t = text.trim(); if (!t) return; setErr("");
    try { await post("/api/chat/send", { text: t }); setText(""); } catch (x) { setErr(errMsg(x)); }
  };

  return (
    <section className="mu-page">
      <Head eyebrow="GROUP CHAT" title="الشات الجماعي" text="غرفة لحظية لمجتمع البوت. الروابط والألفاظ المسيئة ممنوعة." />
      {me === undefined ? null : !me ? (
        <form className="mu-panel mu-panel-inner mu-login" onSubmit={join}>
          <div className="mu-panel-title"><h2>ادخل الغرفة</h2></div>
          <label className="mu-field-label" htmlFor="mu-chat-name">اسمك (2–24 حرفاً)</label>
          <input className="mu-phone-input" id="mu-chat-name" maxLength={24} value={name} onChange={(e) => setName(e.currentTarget.value)} required />
          <label className="mu-field-label" htmlFor="mu-chat-av">صورة (اختيارية)</label>
          <div className="mu-actions-row" style={{ alignItems: "center" }}>
            <input id="mu-chat-av" type="file" accept="image/png,image/jpeg,image/webp" onChange={async (e) => { const f = e.currentTarget.files?.[0]; if (f) { try { setAvatar(await shrinkAvatar(f)); } catch { setErr("تعذّر قراءة الصورة."); } } }} />
            {avatar && <Avatar src={avatar} name={name || "؟"} />}
          </div>
          <Err text={err} />
          <div className="mu-actions-row" style={{ marginTop: 12 }}><button className="mu-btn-primary" type="submit" disabled={name.trim().length < 2}>دخول</button></div>
        </form>
      ) : (
        <div className="mu-panel mu-chat-room">
          <div className="mu-chat-list" role="log" aria-live="polite">
            {msgs.length === 0 && <Empty symbol="💬" title="الغرفة هادئة" text="كن أول من يكتب." />}
            {msgs.map((m) => (
              <div key={m.id} className={`mu-msg ${m.uid === me.id ? "mine" : ""} ${m.dev ? "dev" : ""}`}>
                <Avatar src={m.avatar} name={m.name} />
                <div className="mu-bubble">
                  <div className="mu-msg-meta"><b>{m.name}</b>{m.phone && <span dir="ltr">{m.phone}</span>}<time>{fmtTime(m.ts)}</time></div>
                  <p>{m.text}</p>
                </div>
              </div>
            ))}
            <div ref={end} />
          </div>
          <form className="mu-chat-compose" onSubmit={send}>
            <input className="mu-phone-input" maxLength={300} value={text} onChange={(e) => setText(e.currentTarget.value)} placeholder="اكتب رسالة…" aria-label="رسالة" />
            <button className="mu-btn-primary" type="submit" disabled={!text.trim()}>إرسال</button>
          </form>
          <Err text={err} />
        </div>
      )}
    </section>
  );
}

/* ───────────── الشكاوى ───────────── */

const LS_COMPLAINTS = "musashi-complaints";
const STATUS_AR: Record<string, string> = { new: "جديدة 🆕", review: "قيد المراجعة 👀", resolved: "تم الحل ✅" };

export function ComplaintsPage({ owner }: Common) {
  const [types, setTypes] = useState<Record<string, string>>({});
  const [type, setType] = useState("bug");
  const [text, setText] = useState("");
  const [contact, setContact] = useState("");
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [items, setItems] = useState<J[]>([]);

  const loadMine = async () => {
    let tracked: J[] = [];
    try { tracked = JSON.parse(localStorage.getItem(LS_COMPLAINTS) || "[]"); } catch { /* فارغ */ }
    const out: Record<number, J> = {};
    if (tracked.length) { try { for (const c of (await post("/api/complaints/track", { items: tracked })).items) out[c.id] = c; } catch { /* تجاهل */ } }
    if (owner.me?.authenticated) { try { for (const c of (await get("/api/owner/complaints")).items) out[c.id] = c; } catch { /* تجاهل */ } }
    setItems(Object.values(out).sort((a, b) => b.ts - a.ts));
  };
  useEffect(() => { get("/api/complaints/types").then((r) => setTypes(r.types)).catch(() => {}); void loadMine(); }, [owner.me?.authenticated]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!owner.me?.authenticated) return;
    return listen("/api/owner/stream", { complaint: () => void loadMine() });
  }, [owner.me?.authenticated]); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(""); setOk("");
    try {
      const r = await post("/api/complaints", { type, text, contact });
      try { const l = JSON.parse(localStorage.getItem(LS_COMPLAINTS) || "[]"); l.push({ id: r.id, key: r.trackKey }); localStorage.setItem(LS_COMPLAINTS, JSON.stringify(l.slice(-30))); } catch { /* تجاهل */ }
      setText(""); setContact(""); setOk("وصلت شكواك للمطور ✅ ستتابع حالتها والرد هنا."); await loadMine();
    } catch (x) { setErr(errMsg(x)); }
  };

  return (
    <section className="mu-page">
      <Head eyebrow="SUPPORT INBOX" title="الشكاوى" text="أرسل شكواك للمطور مباشرة (حتى 3 يومياً) وتابع حالتها وردّه." />
      <div className="mu-install-grid">
        <form className="mu-panel mu-panel-inner" onSubmit={submit}>
          <div className="mu-panel-title"><h2>شكوى جديدة</h2></div>
          <label className="mu-field-label" htmlFor="mu-c-type">النوع</label>
          <select className="mu-phone-input" id="mu-c-type" value={type} onChange={(e) => setType(e.currentTarget.value)}>{Object.entries(types).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
          <label className="mu-field-label" htmlFor="mu-c-text">التفاصيل</label>
          <textarea className="mu-phone-input mu-textarea" id="mu-c-text" rows={5} maxLength={1000} value={text} onChange={(e) => setText(e.currentTarget.value)} required />
          <label className="mu-field-label" htmlFor="mu-c-contact">رقم للتواصل (اختياري)</label>
          <input className="mu-phone-input" id="mu-c-contact" dir="ltr" maxLength={40} value={contact} onChange={(e) => setContact(e.currentTarget.value)} />
          <Err text={err} />{ok && <div className="mu-inline-alert">{ok}</div>}
          <div className="mu-actions-row" style={{ marginTop: 12 }}><button className="mu-btn-primary" type="submit" disabled={text.trim().length < 10}>إرسال</button></div>
        </form>
        <div className="mu-panel mu-panel-inner">
          <div className="mu-panel-title"><h2>شكاواي</h2><small>{items.length}</small></div>
          {items.length === 0 ? <Empty symbol="📮" title="لا شكاوى بعد" text="شكاواك المرسلة من هذا المتصفح (أو من حسابك) تظهر هنا." /> : (
            <ul className="mu-ticket-list">{items.map((c) => (
              <li key={c.id}>
                <div className="mu-ticket-head"><b>{c.typeLabel}</b><span className={`mu-chip s-${c.status}`}>{STATUS_AR[c.status]}</span></div>
                <p>{c.text}</p>
                {c.reply && <div className="mu-dev-reply"><b>رد المطور:</b> {c.reply}</div>}
                <small>{fmtDate(c.ts)}</small>
              </li>))}
            </ul>)}
        </div>
      </div>
    </section>
  );
}

/* ───────────── محادثة المطور ───────────── */

export function DevChatPage({ owner, goTo }: Common) {
  const [msgs, setMsgs] = useState<J[]>([]);
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const authed = Boolean(owner.me?.authenticated);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { if (authed) get("/api/owner/devchat").then((r) => setMsgs(r.messages)).catch(() => {}); }, [authed]);
  useEffect(() => { if (!authed) return; return listen("/api/owner/stream", { devchat: (m) => setMsgs((l) => [...l, m]) }); }, [authed]);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);
  const send = async (e: FormEvent) => {
    e.preventDefault(); const t = text.trim(); if (!t) return; setErr("");
    try { const r = await post("/api/owner/devchat", { text: t }); setMsgs((l) => [...l, r.message]); setText(""); } catch (x) { setErr(errMsg(x)); }
  };
  return (
    <section className="mu-page">
      <Head eyebrow="DEVELOPER CONTACT" title="محادثة المطور" text="محادثة خاصة بينك وبين المطور، لا يراها غيركما." />
      {!authed ? (
        <div className="mu-panel mu-panel-inner"><Empty symbol="🔐" title="تحتاج الدخول أولاً" text="هذه المحادثة متاحة لأصحاب البوتات بعد دخول لوحة التحكم." />
          <div className="mu-actions-row" style={{ justifyContent: "center" }}><button className="mu-btn-primary" type="button" onClick={() => goTo("dashboard")}>دخول اللوحة</button></div></div>
      ) : (
        <div className="mu-panel mu-chat-room">
          <div className="mu-chat-list" role="log" aria-live="polite">
            {msgs.length === 0 && <Empty symbol="⌁" title="لا توجد رسائل" text="اكتب للمطور وسيرد عليك هنا." />}
            {msgs.map((m) => (
              <div key={m.id} className={`mu-msg ${m.from === "owner" ? "mine" : "dev"}`}>
                <div className="mu-bubble"><div className="mu-msg-meta"><b>{m.from === "dev" ? "المطور ⚔️" : "أنت"}</b><time>{fmtTime(m.ts)}</time></div><p>{m.text}</p></div>
              </div>))}
            <div ref={end} />
          </div>
          <form className="mu-chat-compose" onSubmit={send}>
            <input className="mu-phone-input" maxLength={1000} value={text} onChange={(e) => setText(e.currentTarget.value)} placeholder="اكتب للمطور…" aria-label="رسالة للمطور" />
            <button className="mu-btn-primary" type="submit" disabled={!text.trim()}>إرسال</button>
          </form>
          <Err text={err} />
        </div>
      )}
    </section>
  );
}

/* ───────────── قناة البوت ───────────── */

export function ChannelPage() {
  const [c, setC] = useState<J | null>(null);
  useEffect(() => { get("/api/channel").then(setC).catch(() => setC({ url: null, announcements: [] })); }, []);
  return (
    <section className="mu-page">
      <Head eyebrow="OFFICIAL CHANNEL" title="قناة البوت" text="القناة الرسمية على واتساب وإعلانات المطور." />
      <div className="mu-panel mu-panel-inner" style={{ marginBottom: 14 }}>
        <div className="mu-panel-title"><h2>📢 قناة واتساب الرسمية</h2></div>
        {c?.url ? <a className="mu-btn-primary" href={c.url} target="_blank" rel="noopener noreferrer">فتح القناة</a>
          : <p className="mu-small-print">لم يُضبط رابط القناة بعد (CHANNEL_URL).</p>}
      </div>
      <div className="mu-panel mu-panel-inner">
        <div className="mu-panel-title"><h2>إعلانات المطور</h2></div>
        {c?.announcements?.length ? <ul className="mu-ticket-list">{c.announcements.map((a: J) => <li key={a.id}><p>{a.text}</p><small>{fmtDate(a.ts)}</small></li>)}</ul>
          : <Empty symbol="📣" title="لا إعلانات حالياً" text="ستظهر إعلانات المطور هنا وفي لوحة التحكم." />}
      </div>
    </section>
  );
}

/* ───────────── لوحة المطور ───────────── */

type Tab = "overview" | "bots" | "complaints" | "chats" | "announce" | "chat" | "events";
const TABS: [Tab, string][] = [["overview", "نظرة عامة"], ["bots", "البوتات"], ["complaints", "الشكاوى"], ["chats", "المحادثات"], ["announce", "الإعلانات"], ["chat", "الشات"], ["events", "السجل"]];

export function DevConsolePage({ toast }: Common) {
  const [auth, setAuth] = useState<boolean | null>(null);
  const [enabled, setEnabled] = useState(true);
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<Tab>("overview");
  useEffect(() => { get("/api/dev/me").then((r) => { setAuth(r.authenticated); setEnabled(r.enabled); }).catch(() => setAuth(false)); }, []);
  const login = async (e: FormEvent) => {
    e.preventDefault(); setErr("");
    try { await post("/api/dev/login", { password: pw }); setPw(""); setAuth(true); } catch (x) { setErr(errMsg(x)); }
  };
  return (
    <section className="mu-page">
      <Head eyebrow="RESTRICTED ACCESS" title="لوحة المطور" text="إدارة البوتات والشكاوى والمحادثات والإعلانات."
        aside={auth ? <button className="mu-btn-quiet" type="button" onClick={async () => { await post("/api/dev/logout"); setAuth(false); }}>خروج</button> : undefined} />
      {auth === null ? null : !auth ? (
        <form className="mu-panel mu-panel-inner mu-login" onSubmit={login}>
          <div className="mu-panel-title"><h2>🔐 دخول المطور</h2></div>
          {!enabled && <div className="mu-form-error">لوحة المطور غير مفعّلة: اضبط DEV_PASSWORD_HASH في الخادم.</div>}
          <label className="mu-field-label" htmlFor="mu-dev-pw">كلمة السر</label>
          <div className="mu-phone-wrap"><input className="mu-phone-input" id="mu-dev-pw" type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.currentTarget.value)} required />
            <button className="mu-btn-primary" type="submit" disabled={!pw || !enabled}>دخول</button></div>
          <Err text={err} />
        </form>
      ) : (
        <>
          <div className="mu-tabs" role="tablist">{TABS.map(([id, label]) => <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? "on" : ""} type="button" onClick={() => setTab(id)}>{label}</button>)}</div>
          {tab === "overview" && <DevOverview />}
          {tab === "bots" && <DevBots toast={toast} />}
          {tab === "complaints" && <DevComplaints toast={toast} />}
          {tab === "chats" && <DevChats toast={toast} />}
          {tab === "announce" && <DevAnnounce toast={toast} />}
          {tab === "chat" && <DevChatMod toast={toast} />}
          {tab === "events" && <DevEvents />}
        </>
      )}
    </section>
  );
}

function useList<T = J>(url: string, key = "items") {
  const [items, setItems] = useState<T[]>([]);
  const reload = () => get(url).then((r) => setItems(r[key])).catch(() => {});
  useEffect(() => { void reload(); }, [url]); // eslint-disable-line react-hooks/exhaustive-deps
  return [items, reload] as const;
}

function DevOverview() {
  const [s, setS] = useState<J | null>(null);
  useEffect(() => { get("/api/dev/stats").then(setS).catch(() => {}); }, []);
  const cards: [string, string, unknown][] = [["إجمالي البوتات", "◈", s?.bots], ["مفعّلة", "◉", s?.active], ["منفصلة", "⚠", s?.disconnected], ["شكاوى جديدة", "📮", s?.complaintsNew], ["رسائل الشات", "💬", s?.chatMessages]];
  return <div className="mu-grid-3">{cards.map(([l, i, v]) => <div className="mu-panel mu-stat" key={l}><span className="mu-stat-icon">{i}</span><span className="mu-stat-label">{l}</span><strong className="mu-stat-value live">{s ? String(v) : "—"}</strong></div>)}</div>;
}

function DevBots({ toast }: { toast: (m: string) => void }) {
  const [items, reload] = useList("/api/dev/bots");
  const act = async (id: string, a: "stop" | "start") => { try { await post(`/api/dev/bots/${id}/${a}`); toast("تم."); void reload(); } catch (e) { toast(errMsg(e)); } };
  const rm = async (id: string) => { if (!confirm("حذف هذا البوت من الموقع؟ سيُخرَج مالكه فوراً.")) return; try { await del(`/api/dev/bots/${id}`); void reload(); } catch (e) { toast(errMsg(e)); } };
  return (
    <div className="mu-panel mu-panel-inner">
      <div className="mu-panel-title"><h2>البوتات</h2><small>{items.length}</small></div>
      {items.length === 0 ? <Empty symbol="◈" title="لا بوتات" text="لم يُنصَّب أي بوت بعد." /> : (
        <ul className="mu-rows">{items.map((b: J) => (
          <li key={b.id}><span dir="ltr">{b.phone}</span><span className={`mu-chip st-${b.state}`}>{STATE_LABEL[b.state] ?? b.state}</span><time>{fmtDate(b.createdAt)}</time>
            <span className="mu-actions-row">
              {b.state === "stopped" ? <button className="mu-btn-quiet" type="button" onClick={() => void act(b.id, "start")}>تشغيل</button> : <button className="mu-btn-quiet" type="button" onClick={() => void act(b.id, "stop")}>إيقاف</button>}
              <button className="mu-btn-quiet danger" type="button" onClick={() => void rm(b.id)}>حذف</button></span></li>))}
        </ul>)}
    </div>
  );
}

function DevComplaints({ toast }: { toast: (m: string) => void }) {
  const [items, reload] = useList("/api/dev/complaints");
  const [reply, setReply] = useState<Record<number, string>>({});
  const save = async (id: number, body: J) => { try { await patch(`/api/dev/complaints/${id}`, body); toast("تم الحفظ."); setReply((r) => ({ ...r, [id]: "" })); void reload(); } catch (e) { toast(errMsg(e)); } };
  return (
    <div className="mu-panel mu-panel-inner">
      <div className="mu-panel-title"><h2>صندوق الشكاوى</h2><small>{items.length}</small></div>
      {items.length === 0 ? <Empty symbol="📮" title="لا شكاوى" text="الصندوق فارغ." /> : (
        <ul className="mu-ticket-list">{items.map((c: J) => (
          <li key={c.id}>
            <div className="mu-ticket-head"><b>{c.typeLabel}{c.phone ? ` · ${c.phone}` : ""}</b>
              <select className="mu-mini-select" value={c.status} onChange={(e) => void save(c.id, { status: e.currentTarget.value })}>{Object.entries(STATUS_AR).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
            <p>{c.text}</p>{c.contact && <small>تواصل: <span dir="ltr">{c.contact}</span></small>}
            {c.reply && <div className="mu-dev-reply"><b>ردك:</b> {c.reply}</div>}
            <div className="mu-chat-compose"><input className="mu-phone-input" placeholder="اكتب رداً…" value={reply[c.id] ?? ""} onChange={(e) => { const v = e.currentTarget.value; setReply((r) => ({ ...r, [c.id]: v })); }} />
              <button className="mu-btn-secondary" type="button" disabled={!reply[c.id]?.trim()} onClick={() => void save(c.id, { reply: reply[c.id] })}>رد</button></div>
            <small>{fmtDate(c.ts)}</small>
          </li>))}
        </ul>)}
    </div>
  );
}

function DevChats({ toast }: { toast: (m: string) => void }) {
  const [items, reload] = useList("/api/dev/chats");
  const [sel, setSel] = useState<J | null>(null);
  const [msgs, setMsgs] = useState<J[]>([]);
  const [text, setText] = useState("");
  const open = async (c: J) => { setSel(c); setMsgs((await get(`/api/dev/chats/${c.botId}`)).messages); };
  const send = async (e: FormEvent) => {
    e.preventDefault(); if (!sel || !text.trim()) return;
    try { const r = await post(`/api/dev/chats/${sel.botId}`, { text }); setMsgs((l) => [...l, r.message]); setText(""); void reload(); } catch (x) { toast(errMsg(x)); }
  };
  return (
    <div className="mu-install-grid">
      <div className="mu-panel mu-panel-inner"><div className="mu-panel-title"><h2>المحادثات الخاصة</h2></div>
        {items.length === 0 ? <Empty symbol="⌁" title="لا محادثات" text="لم يراسلك أحد بعد." /> :
          <ul className="mu-rows">{items.map((c: J) => <li key={c.botId}><button type="button" className="mu-btn-quiet" onClick={() => void open(c)}><span dir="ltr">{c.phone}</span> · {c.count}</button><small>{c.last.text.slice(0, 40)}</small></li>)}</ul>}
      </div>
      <div className="mu-panel mu-chat-room">
        {!sel ? <Empty symbol="💬" title="اختر محادثة" text="" /> : <>
          <div className="mu-chat-list">{msgs.map((m) => <div key={m.id} className={`mu-msg ${m.from === "dev" ? "mine dev" : ""}`}><div className="mu-bubble"><div className="mu-msg-meta"><b>{m.from === "dev" ? "أنت" : sel.phone}</b><time>{fmtTime(m.ts)}</time></div><p>{m.text}</p></div></div>)}</div>
          <form className="mu-chat-compose" onSubmit={send}><input className="mu-phone-input" value={text} onChange={(e) => setText(e.currentTarget.value)} maxLength={1000} placeholder="رد…" /><button className="mu-btn-primary" type="submit">إرسال</button></form></>}
      </div>
    </div>
  );
}

function DevAnnounce({ toast }: { toast: (m: string) => void }) {
  const [items, reload] = useList("/api/announcements");
  const [text, setText] = useState("");
  const add = async (e: FormEvent) => { e.preventDefault(); try { await post("/api/dev/announcements", { text }); setText(""); void reload(); toast("نُشر الإعلان."); } catch (x) { toast(errMsg(x)); } };
  return (
    <div className="mu-panel mu-panel-inner">
      <div className="mu-panel-title"><h2>الإعلانات</h2></div>
      <form className="mu-chat-compose" onSubmit={add}><input className="mu-phone-input" maxLength={500} value={text} onChange={(e) => setText(e.currentTarget.value)} placeholder="نص الإعلان…" /><button className="mu-btn-primary" type="submit" disabled={!text.trim()}>نشر</button></form>
      <ul className="mu-ticket-list" style={{ marginTop: 14 }}>{items.map((a: J) => <li key={a.id}><p>{a.text}</p><small>{fmtDate(a.ts)}</small> <button className="mu-btn-quiet danger" type="button" onClick={async () => { await del(`/api/dev/announcements/${a.id}`); void reload(); }}>حذف</button></li>)}</ul>
    </div>
  );
}

function DevChatMod({ toast }: { toast: (m: string) => void }) {
  const [msgs, reload] = useList("/api/dev/chat/messages");
  const rm = async (id: number) => { try { await del(`/api/dev/chat/${id}`); void reload(); } catch (x) { toast(errMsg(x)); } };
  const mute = async (uid: string, minutes: number) => { try { await post("/api/dev/chat/mute", { uid, minutes }); toast(minutes ? `كُتم ${minutes} دقيقة.` : "كُتم دائماً."); } catch (x) { toast(errMsg(x)); } };
  return (
    <div className="mu-panel mu-panel-inner">
      <div className="mu-panel-title"><h2>إشراف الشات</h2><button className="mu-btn-quiet" type="button" onClick={() => void reload()}>تحديث</button></div>
      {msgs.length === 0 ? <Empty symbol="💬" title="لا رسائل" text="" /> : (
        <ul className="mu-rows">{msgs.map((m: J) => (
          <li key={m.id}><b>{m.name}</b><span>{m.text}</span>
            <span className="mu-actions-row"><button className="mu-btn-quiet" type="button" onClick={() => void mute(m.uid, 60)}>كتم ساعة</button><button className="mu-btn-quiet" type="button" onClick={() => void mute(m.uid, 0)}>كتم دائم</button><button className="mu-btn-quiet danger" type="button" onClick={() => void rm(m.id)}>حذف</button></span></li>))}
        </ul>)}
    </div>
  );
}

function DevEvents() {
  const [items] = useList("/api/dev/events");
  return (
    <div className="mu-panel mu-panel-inner"><div className="mu-panel-title"><h2>سجل الأحداث الكامل</h2><small>{items.length}</small></div>
      <ul className="mu-log">{items.map((e: J) => <li key={e.id}><time>{fmtDate(e.ts)}</time><span>{EVENT_AR[e.type] ?? e.type}</span><small dir="ltr">{e.phone}</small>{e.detail && <small>{e.detail}</small>}</li>)}</ul></div>
  );
}
