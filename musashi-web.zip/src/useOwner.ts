import { useCallback, useEffect, useState } from "react";
import { get, post, listen, type J } from "./api";

export type Owner = {
  me: J | null;
  loading: boolean;
  forced: boolean;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
};

/** حالة دخول المالك + استقبال الخروج الإجباري لحظياً عبر SSE. */
export function useOwner(): Owner {
  const [me, setMe] = useState<J | null>(null);
  const [loading, setLoading] = useState(true);
  const [forced, setForced] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const r = await get("/api/me");
      setMe(r.authenticated ? r : null);
      setForced(Boolean(r.disconnected));
    } catch { setMe(null); }
    setLoading(false);
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  useEffect(() => {
    if (!me?.authenticated) return;
    return listen("/api/owner/stream", {
      "forced-logout": () => { setMe(null); setForced(true); },
      status: (d) => setMe((m: J) => (m ? { ...m, state: d.status } : m)),
    });
  }, [me?.authenticated]);

  const logout = useCallback(async () => {
    try { await post("/api/auth/logout"); } catch { /* تجاهل */ }
    setMe(null); setForced(false);
  }, []);

  return { me, loading, forced, refresh, logout };
}
