import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { MusashiInstall } from "./MusashiInstall";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <MusashiInstall />
  </StrictMode>,
);
