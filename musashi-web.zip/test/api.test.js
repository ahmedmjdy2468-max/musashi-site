import test from "node:test";
import assert from "node:assert/strict";
import { loadConfig } from "../server/config.js";
import { createStore } from "../server/store.js";
import { createApp } from "../server/app.js";
import { createMockAdapter } from "../server/adapters/mock.js";
import { hashPassword } from "../server/security.js";

const PW = "correct-horse-battery";
async function boot(extra = {}) {
  const cfg = loadConfig({ NODE_ENV: "test", SUB_PAIR_CODE: "MUSASH12", SESSION_SECRET: "x".repeat(40), DEV_PASSWORD_HASH: hashPassword(PW), DATA_FILE: "", MAX_BOTS: "3", DIST_DIR: "./nope", ...extra });
  const adapter = createMockAdapter();
  const store = createStore(null);
  const { app, dispose } = createApp({ cfg, store, adapter });
  const server = await new Promise((r) => { const s = app.listen(0, "127.0.0.1", () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const client = () => {
    const jar = {};
    const call = async (method, url, body, headers = {}) => {
      const r = await fetch(base + url, { method, headers: { "content-type": "application/json", cookie: Object.entries(jar).map(([k, v]) => `${k}=${v}`).join("; "), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
      for (const c of r.headers.getSetCookie()) { const [kv, ...attrs] = c.split(";"); const [k, v] = kv.split("="); if (/Max-Age=0/i.test(attrs.join(";"))) delete jar[k]; else jar[k] = v; }
      let json = null; try { json = await r.json(); } catch { /* sse/empty */ }
      return { status: r.status, json, headers: r.headers };
    };
    return { get: (u, h) => call("GET", u, undefined, h), post: (u, b, h) => call("POST", u, b ?? {}, h), patch: (u, b) => call("PATCH", u, b), del: (u) => call("DELETE", u), jar };
  };
  return { adapter, store, client, base, close: () => { dispose(); server.closeAllConnections(); server.close(); } };
}
const sse = async (url, cookie = "") => {
  const ctl = new AbortController();
  const r = await fetch(url, { signal: ctl.signal, headers: { cookie } });
  const reader = r.body.getReader(); const dec = new TextDecoder(); const events = [];
  (async () => { let buf = ""; try { for (;;) { const { value, done } = await reader.read(); if (done) break; buf += dec.decode(value); let i; while ((i = buf.indexOf("\n\n")) >= 0) { const blk = buf.slice(0, i); buf = buf.slice(i + 2); const ev = /event: (.+)/.exec(blk)?.[1]; const d = /data: (.+)/.exec(blk)?.[1]; if (ev) events.push([ev, JSON.parse(d)]); } } } catch { /* abort */ } })();
  return { events, close: () => ctl.abort(), wait: async (name, ms = 2000) => { const t = Date.now(); while (Date.now() - t < ms) { const e = events.find((x) => x[0] === name); if (e) return e[1]; await new Promise((r) => setTimeout(r, 20)); } throw new Error("timeout waiting " + name); } };
};
const PHONE = "96891234567";

async function install(s, c, phone = PHONE) {
  const r = await c.post("/api/install", { phone });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  const stream = await sse(`${s.base}/api/install/events?t=${r.json.watch}`);
  const pair = await stream.wait("pair");
  s.adapter.simulateReady(phone);
  await stream.wait("ready");
  stream.close();
  return pair;
}
async function login(s, c, phone = PHONE) {
  await c.post("/api/auth/request", { phone });
  const code = s.adapter.lastCode(phone);
  assert.match(code, /^\d{6}$/);
  return { code, res: await c.post("/api/auth/verify", { phone, code }) };
}

test("تنصيب: الكود الثابت 8 أحرف عبر حدث pair ثم ready", async () => {
  const s = await boot(); const c = s.client();
  const pair = await install(s, c);
  assert.equal(pair.code, "MUSASH12");
  s.close();
});

test("إعداد خاطئ: SUB_PAIR_CODE بشرطة أو أطول من 8 يرفض التشغيل", () => {
  assert.throws(() => loadConfig({ SUB_PAIR_CODE: "ABCD-EFG", SESSION_SECRET: "x".repeat(40) }));
  assert.throws(() => loadConfig({ SUB_PAIR_CODE: "ABCDEFGHI", SESSION_SECRET: "x".repeat(40) }));
});

test("تنصيب واحد لكل رقم: المفعّل لا يُنصَّب مجدداً، والمنفصل يُسمح له", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c);
  const dup = await c.post("/api/install", { phone: PHONE });
  assert.equal(dup.status, 409); assert.equal(dup.json.error, "ACTIVE");
  s.adapter.simulateClose(PHONE);
  const re = await c.post("/api/install", { phone: PHONE });
  assert.equal(re.status, 200); assert.equal(re.json.reinstall, true);
  s.close();
});

test("رقم غير صالح + سعة ممتلئة", async () => {
  const s = await boot(); const c = s.client();
  assert.equal((await c.post("/api/install", { phone: "abc" })).status, 400);
  for (const p of ["96800000001", "96800000002", "96800000003"]) await c.post("/api/install", { phone: p });
  assert.equal((await c.post("/api/install", { phone: "96800000004" })).json.error, "FULL");
  s.close();
});

test("دخول: كود 6 أرقام، استخدام واحد، جلسة HttpOnly باقية", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c);
  const req = await c.post("/api/auth/request", { phone: PHONE });
  assert.equal(req.status, 200);
  const code = s.adapter.lastCode(PHONE);
  assert.ok(s.adapter.outbox.at(-1).text.includes(code));
  const ok = await c.post("/api/auth/verify", { phone: PHONE, code });
  assert.equal(ok.status, 200);
  const setCookie = ok.headers.getSetCookie().join(";");
  assert.match(setCookie, /HttpOnly/); assert.match(setCookie, /SameSite=Lax/);
  assert.equal((await c.get("/api/me")).json.authenticated, true);
  assert.equal((await c.get("/api/owner/dashboard")).status, 200);
  // replay من عميل آخر بنفس الكود
  const c2 = s.client();
  assert.equal((await c2.post("/api/auth/verify", { phone: PHONE, code })).status, 401);
  s.close();
});

test("الكود المنتهي (5 دقائق) يُرفض", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c);
  await c.post("/api/auth/request", { phone: PHONE });
  const code = s.adapter.lastCode(PHONE);
  const real = Date.now; Date.now = () => real() + 5 * 60_000 + 1000;
  try { assert.equal((await c.post("/api/auth/verify", { phone: PHONE, code })).status, 401); } finally { Date.now = real; }
  s.close();
});

test("رقم غير مسجل: رد موحّد ولا رسالة تُرسل", async () => {
  const s = await boot(); const c = s.client();
  const r = await c.post("/api/auth/request", { phone: "96899999999" });
  assert.equal(r.status, 200); assert.equal(s.adapter.outbox.length, 0);
  s.close();
});

test("5 محاولات خاطئة ثم قفل حتى مع الكود الصحيح", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c);
  await c.post("/api/auth/request", { phone: PHONE });
  const good = s.adapter.lastCode(PHONE);
  const wrong = good === "000000" ? "111111" : "000000";
  for (let i = 0; i < 4; i++) assert.equal((await c.post("/api/auth/verify", { phone: PHONE, code: wrong })).status, 401);
  assert.equal((await c.post("/api/auth/verify", { phone: PHONE, code: wrong })).status, 423);
  assert.equal((await c.post("/api/auth/verify", { phone: PHONE, code: good })).status, 423);
  s.close();
});

test("انفصال close: خروج إجباري فوري + حدث SSE + رسالة المنفصل", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c); await login(s, c);
  const stream = await sse(`${s.base}/api/owner/stream`, `ms=${c.jar.ms}`);
  await stream.wait("status");
  s.adapter.simulateClose(PHONE);
  await stream.wait("forced-logout");
  const r = await c.get("/api/owner/dashboard");
  assert.equal(r.status, 401);
  assert.equal((await c.get("/api/me")).json.authenticated, false);
  stream.close(); s.close();
});

test("badSession يلغي الجلسة أيضاً، وإعادة التنصيب ثم دخول جديد مع بقاء البيانات", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c); await login(s, c);
  await c.post("/api/owner/devchat", { text: "مرحبا" });
  s.adapter.simulateBadSession(PHONE);
  await new Promise((r) => setTimeout(r, 50));
  assert.equal((await c.get("/api/owner/dashboard")).status, 401);
  await install(s, c);                       // إعادة التنصيب
  const l = await login(s, c);               // دخول جديد
  assert.equal(l.res.status, 200);
  const chat = await c.get("/api/owner/devchat");
  assert.equal(chat.json.messages.length, 1); // البيانات محفوظة
  s.close();
});

test("إيقاف/تشغيل البوت من اللوحة لا يطرد المالك", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c); await login(s, c);
  assert.equal((await c.post("/api/owner/bot/stop")).json.state, "stopped");
  assert.equal((await c.get("/api/owner/dashboard")).status, 200);
  assert.equal((await c.post("/api/owner/bot/start")).json.state, "connected");
  assert.equal((await c.post("/api/owner/bot/hack")).status, 404);
  s.close();
});

test("CSRF: أصل خارجي مرفوض", async () => {
  const s = await boot(); const c = s.client();
  const r = await c.post("/api/install", { phone: PHONE }, { origin: "https://evil.example" });
  assert.equal(r.status, 403);
  s.close();
});

test("الشات: دخول، حد ثانيتين، روابط وكلمات مسيئة، 200 رسالة، الرقم مقنّع", async () => {
  const s = await boot(); const c = s.client();
  await install(s, c); await login(s, c);
  assert.equal((await c.post("/api/chat/send", { text: "x" })).status, 401);
  assert.equal((await c.post("/api/chat/join", { name: "محمد", avatar: "data:text/html;base64,AAA" })).status, 400);
  assert.equal((await c.post("/api/chat/join", { name: "محمد" })).status, 200);
  const stream = await sse(`${s.base}/api/chat/stream`, `mu=${c.jar.mu}`);
  await stream.wait("history");
  assert.equal((await c.post("/api/chat/send", { text: "السلام عليكم" })).status, 200);
  const m = await stream.wait("message");
  assert.equal(m.phone, "+968***567"); assert.equal(m.name, "محمد");
  assert.equal((await c.post("/api/chat/send", { text: "ثاني" })).status, 429);
  const real = Date.now; let t = real(); Date.now = () => (t += 2500);
  try {
    assert.equal((await c.post("/api/chat/send", { text: "زر https://evil.com الآن" })).json.error, "LINK");
    assert.equal((await c.post("/api/chat/send", { text: "wa.me/123" })).json.error, "LINK");
    assert.equal((await c.post("/api/chat/send", { text: "انت حمارر" })).json.error, "BAD");
    assert.equal((await c.post("/api/chat/send", { text: "x".repeat(900) })).status, 200); // يُقتطع إلى 300
    for (let i = 0; i < 205; i++) { Date.now = () => (t += 2500); await c.post("/api/chat/send", { text: "رسالة " + i }); }
  } finally { Date.now = real; }
  assert.equal(s.store.data.chat.length, 200);
  assert.ok(s.store.data.chat.every((x) => x.text.length <= 300));
  stream.close(); s.close();
});

test("الشكاوى: 3 يومياً، تصل المطور، رد المطور يظهر للمشتكي", async () => {
  const s = await boot(); const c = s.client(); const d = s.client();
  assert.equal((await d.post("/api/dev/login", { password: PW })).status, 200);
  const r1 = await c.post("/api/complaints", { type: "bug", text: "البوت لا يرد على الأوامر", contact: "0501" });
  assert.equal(r1.status, 200);
  const list = await d.get("/api/dev/complaints");
  assert.equal(list.json.items.length, 1); assert.equal(list.json.items[0].status, "new");
  await d.patch(`/api/dev/complaints/${r1.json.id}`, { reply: "تم إصلاحها", status: "resolved" });
  const tr = await c.post("/api/complaints/track", { items: [{ id: r1.json.id, key: r1.json.trackKey }, { id: r1.json.id, key: "bad" }] });
  assert.equal(tr.json.items.length, 1);
  assert.equal(tr.json.items[0].reply, "تم إصلاحها"); assert.equal(tr.json.items[0].status, "resolved");
  await c.post("/api/complaints", { type: "bug", text: "مشكلة ثانية طويلة كفاية" });
  await c.post("/api/complaints", { type: "bug", text: "مشكلة ثالثة طويلة كفاية" });
  assert.equal((await c.post("/api/complaints", { type: "bug", text: "مشكلة رابعة طويلة كفاية" })).status, 429);
  s.close();
});

test("محادثة المطور: عزل بين المالكين + رد ذهبي من المطور", async () => {
  const s = await boot(); const a = s.client(); const b = s.client(); const d = s.client();
  await install(s, a, PHONE); await install(s, b, "96899887766");
  await login(s, a, PHONE); await login(s, b, "96899887766");
  await a.post("/api/owner/devchat", { text: "أحتاج مساعدة" });
  assert.equal((await b.get("/api/owner/devchat")).json.messages.length, 0);
  await d.post("/api/dev/login", { password: PW });
  const chats = await d.get("/api/dev/chats");
  assert.equal(chats.json.items.length, 1);
  await d.post(`/api/dev/chats/${chats.json.items[0].botId}`, { text: "تفضل" });
  const m = (await a.get("/api/owner/devchat")).json.messages;
  assert.deepEqual(m.map((x) => x.from), ["owner", "dev"]);
  s.close();
});

test("لوحة المطور: كلمة سر، قفل 5 محاولات، قوائم، إعلان، حذف رسالة وكتم، حذف بوت", async () => {
  const s = await boot(); const d = s.client(); const u = s.client();
  assert.equal((await d.get("/api/dev/stats")).status, 401);
  for (let i = 0; i < 4; i++) assert.equal((await d.post("/api/dev/login", { password: "wrong" })).status, 401);
  assert.equal((await d.post("/api/dev/login", { password: "wrong" })).status, 423);
  assert.equal((await d.post("/api/dev/login", { password: PW })).status, 423);
  s.close();

  const s2 = await boot(); const d2 = s2.client(); const o = s2.client(); const u2 = s2.client();
  assert.equal((await d2.post("/api/dev/login", { password: PW })).status, 200);
  await install(s2, o); 
  const bots = await d2.get("/api/dev/bots");
  assert.equal(bots.json.items[0].phone, "+968***567"); assert.ok(!JSON.stringify(bots.json).includes(PHONE));
  const ann = await d2.post("/api/dev/announcements", { text: "تحديث جديد 🎉" });
  assert.equal((await u2.get("/api/announcements")).json.items[0].text, "تحديث جديد 🎉");
  assert.equal((await u2.get("/api/channel")).json.announcements.length, 1);
  await u2.post("/api/chat/join", { name: "سالم" });
  await u2.post("/api/chat/send", { text: "اهلا" });
  const msg = s2.store.data.chat[0];
  await d2.post("/api/dev/chat/mute", { uid: msg.uid, minutes: 10 });
  assert.equal((await u2.post("/api/chat/send", { text: "ثانية" })).status, 403);
  await d2.del(`/api/dev/chat/${msg.id}`);
  assert.equal(s2.store.data.chat.length, 0);
  assert.ok((await d2.get("/api/dev/events")).json.items.length > 3);
  const stats = await d2.get("/api/dev/stats");
  assert.equal(stats.json.active, 1);
  await d2.del(`/api/dev/bots/${bots.json.items[0].id}`);
  assert.equal((await d2.get("/api/dev/bots")).json.items.length, 0);
  s2.close();
});

test("الإحصائيات حقيقية: أماكن متاحة وبوتات مفعلة", async () => {
  const s = await boot(); const c = s.client();
  assert.deepEqual((await c.get("/api/stats")).json, { total: 3, available: 3, active: 0, disconnected: 0 });
  await install(s, c);
  assert.deepEqual((await c.get("/api/stats")).json, { total: 3, available: 2, active: 1, disconnected: 0 });
  s.adapter.simulateClose(PHONE);
  assert.equal((await c.get("/api/stats")).json.disconnected, 1);
  s.close();
});

test("ترويسات الأمان وعدم تسريب الأسرار", async () => {
  const s = await boot(); const c = s.client();
  const r = await c.get("/api/stats");
  assert.match(r.headers.get("content-security-policy"), /default-src 'self'/);
  assert.equal(r.headers.get("x-frame-options"), "DENY");
  assert.equal((await c.get("/.env")).status, 404);
  s.close();
});
