# MUSASHI BOT — واجهة موقع التنصيب

واجهة عربية RTL (React + Vite) لموقع تنصيب MUSASHI BOT v5.0: تنصيب، لوحة تحكم، أوامر، شات، شكاوى، محادثة المطور، قناة البوت، تخصيص الموقع، لوحة المطور.

> **الحالة:** واجهة فقط (Frontend). لا يوجد server.js ولا ربط بـ SubBots أو واتساب بعد؛ كل البيانات الحية تظهر "بانتظار الربط". التخصيص (الألوان، الخلفية، الوضع، صوت النقر) يُحفظ محلياً في المتصفح.

## التشغيل
```bash
npm install
npm run dev        # تطوير
npm run build      # بناء إلى dist/
npm run preview    # معاينة البناء
```
المخرجات في `dist/` ثابتة وتعمل على أي استضافة أو مسار فرعي (`base: "./"`).

## النشر على GitHub Pages
ضع المجلد داخل المستودع باسم `web/` (هكذا يعمل ملف `.github/workflows/pages.yml`)، ثم فعّل Settings ⬅ Pages ⬅ Source: GitHub Actions.
إن كان المستودع خاصاً فـ Pages يتطلب خطة تدعمه.

## ملاحظات قبل النشر العلني
- `public/images/musashi/pans-labyrinth-lullaby.mp3` أغنية تجارية (حقوق نشر) — استبدلها بموسيقى مرخّصة أو احذفها قبل جعل المستودع عاماً.
- صور الخلفيات: تأكد أنك تملك حق استخدامها.
- خط Cairo يُحمّل من Google Fonts.
- الخطوة التالية: بناء `server.js` (Express + SSE) وربطه بأحداث `pair/ready/close/badSession` في `sub.js` كما في وصف المشروع.
