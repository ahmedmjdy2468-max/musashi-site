# MUSASHI BOT — موقع التنصيب (واجهة + خادم)

موقع عربي RTL لبوت MUSASHI BOT v5.0: تنصيب برقم واتساب، لوحة تحكم، أوامر، شات جماعي لحظي، شكاوى، محادثة المطور، قناة، تخصيص، ولوحة مطور.
**Express 5 + SSE + React/Vite.** الموقع طبقة ويب فوق البوت ولا يلمس `core/meowsab.js` ولا الجلسات ولا Baileys.

## الحالة بصدق
| | |
|---|---|
| الخادم + الواجهة + كل التدفقات | مُنجز ومُختبر (18 اختبار API + اختبار متصفح شامل) مع **محوّل تجريبي (mock)** |
| الربط بـ `sub.js` الحقيقي | **غير مُنجز/غير مُختبر**: `server/adapters/real.js` قالب مبني على افتراضات، عليه علامات `TODO(map)` |
| اختبار مع واتساب حقيقي | لم يحدث |

## التشغيل المحلي (تجربة بالمحوّل التجريبي)
```bash
npm install
cp .env.example .env     # عدّل SESSION_SECRET و DEV_PASSWORD_HASH، وBOT_ADAPTER=mock
npm run hash-password    # يولّد DEV_PASSWORD_HASH
npm run build            # يبني الواجهة إلى dist/
npm start                # http://localhost:3000
npm test                 # 18 اختبار
```
في وضع mock يطبع الخادم رمز الدخول (6 أرقام) في الطرفية بدل إرساله لواتساب.

## الربط بالبوت (الخطوة المتبقية)
في ملف تشغيل البوت، بعد تهيئة `SubBots` والبوت الرئيسي:
```js
import { startWeb } from "./web/server.js";
import { createRealAdapter } from "./web/server/adapters/real.js";
startWeb({ adapter: createRealAdapter({ SubBots: global.subBots, mainSock: () => global.conn, getCommandCategories }) });
```
**واجهة المحوّل** (كل ما يحتاجه الموقع، وهو `EventEmitter`):

| العضو | المعنى |
|---|---|
| أحداث `pair` `ready` `close` `badSession` | الحمولة `{ phone, code? }` (أرقام فقط بلا `@s.whatsapp.net`) |
| `state(phone)` | `connected` · `stopped` · `pairing` · `disconnected` · `none` |
| `requestPair(phone, code)` | يستدعي `SubBots.pariCode` بالكود الثابت `SUB_PAIR_CODE` |
| `cleanSession(phone)` | تنظيف الجلسة التالفة **فقط** (لا تحذف بيانات UltraDB) |
| `sendMain(phone, text)` | يرسل عبر **البوت الرئيسي** (لا الفرعي) كي يصل الكود حتى لو انفصل بوت المالك |
| `stop/start/remove(phone)` | إيقاف/تشغيل/حذف |
| `stats(phone)` | اختياري (كائن أو `null`) |
| `commands()` | `[{ id, icon, title, commands:[{ name, desc }] }]` من `modules/` و`core/commandDocs.js` |

افتح `real.js` وطابق كل `TODO(map)` مع شيفرة `sub.js` الفعلية.

## تدفقات الموقع
- **تنصيب:** رقم ⬅ `POST /api/install` ⬅ حدث `pair` يعرض الكود لحظياً ⬅ `ready` يعرض «✅ تم ربط بوتك بنجاح». رقم مفعّل يرى «البوت مفعّل ✅» ولا يُنصَّب مجدداً؛ المنفصل يُسمح له بإعادة التنصيب.
- **دخول:** رقم ⬅ كود 6 أرقام عبر البوت الرئيسي (عشوائي، 5 دقائق، استخدام واحد، HMAC-SHA256) ⬅ كوكي `HttpOnly; SameSite=Lax` (+`Secure` على HTTPS) وجلسة تبقى 30 يوماً.
- **انفصال:** `close`/`badSession` يلغيان الجلسة فوراً ويدفعان `forced-logout` عبر SSE ⬅ «البوت منفصل ⚠️ — أعد التنصيب»؛ بعد إعادة التنصيب يدخل بكود جديد وبياناته محفوظة.

## الأمان (مُطبَّق ومُختبر)
5 محاولات خاطئة ⬅ قفل 15 دقيقة (المالك والمطور) · حدود معدّل لكل المسارات الحساسة · فحص `Origin` ضد CSRF · CSP وترويسات أمان · كلمة سر المطور scrypt · لا تعداد للأرقام عند طلب الكود · لا أسرار في الواجهة · سجل لكل تسجيل/دخول/خروج إجباري/إصدار كود (يُسجَّل حدث الإصدار دون الكود).

## قبل الإنتاج
- شغّل خلف HTTPS (Nginx/Cloudflare) واضبط `TRUST_PROXY=1`.
- التخزين الحالي ملف JSON (`DATA_FILE`)؛ للنقل إلى UltraDB استبدل `server/store.js` فقط.
- الجلسات وحدود المعدّل والأكواد في ذاكرة العملية: نسخة واحدة من الخادم (لا cluster).
- `public/images/musashi/pans-labyrinth-lullaby.mp3` أغنية عليها حقوق نشر: استبدلها أو احذفها قبل جعل المستودع عاماً.

## النشر
- الواجهة وحدها (بدون خادم) تعمل على GitHub Pages عبر `.github/workflows/pages.yml`، لكنها لن تتصل بأي API؛ الموقع الكامل يتطلب تشغيل `server.js`.
